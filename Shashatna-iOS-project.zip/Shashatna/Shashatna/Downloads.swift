import SwiftUI
import Foundation
import Combine
import UIKit

struct OfflineEntry: Codable, Identifiable {
    let id: String
    let show: Show
    let sourceID: String
    let quality: String
    var status: String
    var progress: Double
    var bytes: Int64
    var error: String?
}

@MainActor final class DownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {
    static let shared = DownloadManager()
    nonisolated static let sessionIdentifier = "com.shashatna.background-downloads.v1"
    nonisolated let folder: URL
    @Published var entries: [OfflineEntry] = []
    var backgroundCompletion: (() -> Void)?
    private var tasks: [String: URLSessionDownloadTask] = [:]
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: Self.sessionIdentifier)
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        config.httpMaximumConnectionsPerHost = 2
        config.httpShouldSetCookies = false
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    override init() {
        folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Offline", isDirectory: true)
        super.init()
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var protectedFolder = folder
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? protectedFolder.setResourceValues(values)
        let manifest = folder.appendingPathComponent("downloads.json")
        if let data = try? Data(contentsOf: manifest), let stored = try? JSONDecoder().decode([OfflineEntry].self, from: data) {
            entries = stored
        }
        _ = session
        restoreTasks()
    }

    func localURL(_ entry: OfflineEntry) -> URL? {
        guard UUID(uuidString: entry.id) != nil else { return nil }
        let url = folder.appendingPathComponent(entry.id + ".mp4")
        return entry.status == "complete" && FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    func enqueue(show: Show, sourceID: String, variant: PlaybackVariant) {
        guard variant.container == "mp4" || variant.url.pathExtension.lowercased() == "mp4" else { return }
        guard variant.url.scheme?.lowercased() == "https" else { return }
        guard !entries.contains(where: { $0.show.id == show.id && $0.sourceID == sourceID && $0.quality == variant.label && ["downloading", "complete"].contains($0.status) }) else { return }
        let entry = OfflineEntry(id: UUID().uuidString, show: show, sourceID: sourceID, quality: variant.label, status: "downloading", progress: 0, bytes: 0, error: nil)
        entries.insert(entry, at: 0)
        start(entry: entry, url: variant.url)
    }

    func retry(_ entry: OfflineEntry) {
        guard entry.status == "failed" else { return }
        Task {
            do {
                guard !entry.sourceID.isEmpty, entry.sourceID.utf8.allSatisfy({ (48...57).contains($0) }) else { return }
                let url = URL(string: "https://cinemana.shabakaty.com/api/android/transcoddedFiles/id/" + entry.sourceID)!
                let data = try await LibraryAPI.read(url)
                let choices = try PlaybackOptionsView.parseVariants(data)
                guard let selected = choices.first(where: { $0.label == entry.quality && ($0.container == "mp4" || $0.url.pathExtension.lowercased() == "mp4") }) else { throw LibraryAPI.APIError.response }
                guard let index = entries.firstIndex(where: { $0.id == entry.id }) else { return }
                entries[index].status = "downloading"
                entries[index].error = nil
                entries[index].progress = 0
                start(entry: entries[index], url: selected.url)
            } catch {
                if let index = entries.firstIndex(where: { $0.id == entry.id }) {
                    entries[index].error = "تعذّر الحصول على رابط تحميل جديد من المصدر."
                    save()
                }
            }
        }
    }

    func remove(_ entry: OfflineEntry) {
        tasks.removeValue(forKey: entry.id)?.cancel()
        entries.removeAll { $0.id == entry.id }
        if UUID(uuidString: entry.id) != nil { try? FileManager.default.removeItem(at: folder.appendingPathComponent(entry.id + ".mp4")) }
        save()
    }

    private func start(entry: OfflineEntry, url: URL) {
        var request = URLRequest(url: CinemanaMediaRoute.candidates(url).first ?? url)
        CinemanaPlaybackProfile.apply(to: &request)
        request.allowsCellularAccess = !UserDefaults.standard.bool(forKey: "downloadWiFiOnly")
        let task = session.downloadTask(with: request)
        task.taskDescription = entry.id
        tasks[entry.id] = task
        save()
        task.resume()
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(entries) else { return }
        try? data.write(to: folder.appendingPathComponent("downloads.json"), options: .atomic)
    }

    private func restoreTasks() {
        session.getAllTasks { [weak self] active in
            Task { @MainActor in
                guard let self = self else { return }
                for task in active {
                    guard let download = task as? URLSessionDownloadTask, let id = task.taskDescription else { continue }
                    if self.entries.contains(where: { $0.id == id }) { self.tasks[id] = download }
                    else { download.cancel() }
                }
                for index in self.entries.indices {
                    let entry = self.entries[index]
                    if entry.status == "downloading" && self.tasks[entry.id] == nil {
                        self.entries[index].status = "failed"
                        self.entries[index].error = "انقطع التحميل. أعد المحاولة."
                    }
                    if entry.status == "complete" && self.localURL(entry) == nil {
                        self.entries[index].status = "failed"
                        self.entries[index].error = "الملف المحلي غير موجود."
                    }
                }
                self.save()
            }
        }
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                               totalBytesExpectedToWrite: Int64) {
        guard let id = downloadTask.taskDescription else { return }
        Task { @MainActor [weak self] in
            guard let self = self, let index = self.entries.firstIndex(where: { $0.id == id }) else { return }
            self.entries[index].bytes = totalBytesWritten
            self.entries[index].progress = totalBytesExpectedToWrite > 0 ? min(Double(totalBytesWritten) / Double(totalBytesExpectedToWrite), 1) : 0
        }
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didFinishDownloadingTo location: URL) {
        guard let id = downloadTask.taskDescription, UUID(uuidString: id) != nil else { return }
        let target = folder.appendingPathComponent(id + ".mp4")
        do {
            guard let response = downloadTask.response as? HTTPURLResponse, (200...299).contains(response.statusCode) else { throw LibraryAPI.APIError.response }
            let handle = try FileHandle(forReadingFrom: location)
            let header = try handle.read(upToCount: 64) ?? Data()
            try handle.close()
            // Do not save an HTML error page or playlist as an MP4 download.
            guard header.range(of: Data("ftyp".utf8)) != nil else { throw LibraryAPI.APIError.response }
            if FileManager.default.fileExists(atPath: target.path) { try FileManager.default.removeItem(at: target) }
            // The temporary file must be moved before this delegate callback returns.
            try FileManager.default.moveItem(at: location, to: target)
            let bytes = ((try? FileManager.default.attributesOfItem(atPath: target.path)[.size]) as? NSNumber)?.int64Value ?? 0
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                guard let index = self.entries.firstIndex(where: { $0.id == id }) else { try? FileManager.default.removeItem(at: target); return }
                self.entries[index].status = "complete"
                self.entries[index].progress = 1
                self.entries[index].bytes = bytes
                self.entries[index].error = nil
                self.tasks.removeValue(forKey: id)
                self.save()
            }
        } catch {
            Task { @MainActor [weak self] in self?.fail(id: id, message: "تعذّر حفظ ملف MP4. تحقق من المساحة وإتاحة التحميل من المصدر.") }
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error, let id = task.taskDescription else { return }
        let code = (error as NSError).code
        Task { @MainActor [weak self] in self?.fail(id: id, message: "تعذّر التحميل (\(code)). أعد المحاولة من شبكة تصل إلى المصدر.") }
    }
    private func fail(id: String, message: String) {
        guard let index = entries.firstIndex(where: { $0.id == id }), entries[index].status != "complete" else { return }
        entries[index].status = "failed"
        entries[index].error = message
        tasks.removeValue(forKey: id)
        save()
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor [weak self] in
            let completion = self?.backgroundCompletion
            self?.backgroundCompletion = nil
            completion?()
        }
    }
}

@MainActor final class DownloadAppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        if identifier == DownloadManager.sessionIdentifier { DownloadManager.shared.backgroundCompletion = completionHandler }
        else { completionHandler() }
    }
}

struct DownloadsView: View {
    @EnvironmentObject private var downloads: DownloadManager
    @AppStorage("downloadWiFiOnly") private var wifiOnly = false
    var body: some View {
        List {
            Section {
                Toggle("تحميل جديد عبر Wi-Fi فقط", isOn: $wifiOnly)
                Text("تطبق على التنزيلات الجديدة. الملفات محفوظة داخل التطبيق ويمكن تشغيل المكتمل منها دون إنترنت.").font(.caption).foregroundStyle(.secondary)
            }
            if downloads.entries.isEmpty {
                Text("لا توجد تنزيلات. افتح عملًا واختر الجودة ثم اضغط تحميل.").foregroundStyle(.secondary)
            }
            ForEach(downloads.entries) { entry in
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text(entry.show.title).font(.headline)
                        Spacer()
                        Text(entry.quality).font(.caption).foregroundStyle(Theme.accent)
                    }
                    if let url = downloads.localURL(entry) {
                        NavigationLink {
                            PlayerScreen(episode: Episode(id: "source-" + entry.sourceID, title: entry.show.title, season: 1, number: 1, streamURL: url), showID: entry.show.id, show: entry.show)
                        } label: { Label("تشغيل بدون إنترنت", systemImage: "play.circle.fill") }
                    } else if entry.status == "downloading" {
                        ProgressView(value: entry.progress)
                        Text("جاري التحميل • " + ByteCountFormatter.string(fromByteCount: entry.bytes, countStyle: .file)).font(.caption)
                    } else {
                        Text(entry.error ?? "تعذّر التحميل").font(.caption).foregroundStyle(.orange)
                        Button("إعادة المحاولة") { downloads.retry(entry) }
                    }
                    if entry.status == "complete" { Text(ByteCountFormatter.string(fromByteCount: entry.bytes, countStyle: .file)).font(.caption).foregroundStyle(.secondary) }
                    Button(entry.status == "downloading" ? "إلغاء التحميل" : "حذف", role: .destructive) { downloads.remove(entry) }
                        .font(.caption)
                }.padding(.vertical, 7)
            }
        }.scrollContentBackground(.hidden).background(Theme.background).navigationTitle("التنزيلات")
    }
}

struct SavedLibraryView: View {
    @EnvironmentObject private var catalog: Catalog
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text("كل ما تحب، بمكان واحد").font(.title.bold())
                NavigationLink { DownloadsView() } label: {
                    HStack {
                        Image(systemName: "arrow.down.circle.fill").font(.title)
                        VStack(alignment: .leading, spacing: 5) {
                            Text("التنزيلات").font(.headline)
                            Text("شاهد الملفات المكتملة بدون إنترنت").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.left")
                    }.padding(20).background(Theme.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 22))
                }
                NavigationLink { BrowseView(searchable: false, favoritesOnly: true) } label: {
                    Label("المفضلة", systemImage: "bookmark.fill").font(.headline).padding(18)
                }.buttonStyle(.bordered)
                if !catalog.resumeRecords.isEmpty {
                    Text("متابعة المشاهدة").font(.title2.bold())
                    ForEach(catalog.resumeRecords) { record in
                        HStack {
                            NavigationLink { DetailView(show: record.show) } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(record.show.title).font(.headline)
                                    Text("من الدقيقة \(Int(record.seconds / 60))").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            Button { catalog.removeResume(record.id) } label: { Image(systemName: "xmark.circle") }
                                .accessibilityLabel("إزالة من متابعة المشاهدة")
                        }.padding(16).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 16))
                    }
                }
            }.padding(20)
        }.background(Theme.background).navigationTitle("مكتبتي")
    }
}
