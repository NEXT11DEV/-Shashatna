import SwiftUI
import Foundation
import Combine

enum LibraryAPI {
    static func read(_ address: URL) async throws -> Data {
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil
        config.urlCredentialStorage = nil
        config.timeoutIntervalForRequest = 20
        config.timeoutIntervalForResource = 30
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: address, cachePolicy: .reloadIgnoringLocalCacheData)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (file, response) = try await session.download(for: request)
        defer { try? FileManager.default.removeItem(at: file) }
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode), http.url?.host == address.host else { throw APIError.response }
        let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
        guard ((attrs[.size] as? NSNumber)?.intValue ?? 0) <= 5_000_000 else { throw APIError.response }
        return try Data(contentsOf: file)
    }
    enum APIError: Error { case response }
}

@MainActor final class LibraryBrowseModel: ObservableObject {
    @Published var items: [Show] = []
    @Published var loading = false
    @Published var message: String?
    @Published var ended = false
    private var query = ""
    private var mediaType = "movie"
    @Published private(set) var page = 1
    private var generation = 0
    private var fetchedIDs = Set<String>()
    private var retryingPartialPage = false

    func reset(query: String, mediaType: String = "movie") async {
        generation += 1
        self.query = Self.cleanQuery(query)
        self.mediaType = mediaType
        page = 1
        items = []
        fetchedIDs = []
        retryingPartialPage = false
        ended = false
        loading = false
        await more()
    }

    func more() async {
        guard !loading, !ended else { return }
        let current = generation
        let requestedQuery = query
        let requestedPage = page
        let requestedType = mediaType
        loading = true
        message = nil
        defer { if current == generation { loading = false } }
        let types = ["animation", "all"].contains(requestedType) ? ["movie", "series"] : [requestedType]
        var decoded: [Show] = []
        var failedTypes = 0
        let terms = requestedQuery.isEmpty ? [""] : TitleSearch.variants(requestedQuery)
        let addresses = terms.flatMap { term in types.compactMap { type -> URL? in
            var parts = URLComponents(string: "https://cinemana.shabakaty.com/api/android/AdvancedSearch")!
            parts.queryItems = [URLQueryItem(name: "videoTitle", value: term), URLQueryItem(name: "type", value: type), URLQueryItem(name: "page", value: String(requestedPage))]
            return parts.url
        } }
        let responses = await withTaskGroup(of: Data?.self, returning: [Data?].self) { group in
            for address in addresses { group.addTask { try? await LibraryAPI.read(address) } }
            var results: [Data?] = []
            for await data in group { results.append(data) }
            return results
        }
        guard current == generation, !Task.isCancelled else { return }
        for response in responses {
            do {
                guard let data = response else { throw LibraryAPI.APIError.response }
                decoded += try Catalog.decodeShabakaty(data)
            } catch {
                if Task.isCancelled { return }
                failedTypes += 1
            }
        }
        if decoded.isEmpty && failedTypes == 0 && !requestedQuery.isEmpty {
            var parts = URLComponents(string: "https://cinemana.shabakaty.com/api/android/AdvancedSearch")!
            parts.queryItems = [URLQueryItem(name: "videoTitle", value: requestedQuery), URLQueryItem(name: "page", value: String(requestedPage))]
            do {
                if let url = parts.url { decoded = try Catalog.decodeShabakaty(await LibraryAPI.read(url)) }
            } catch {
                if Task.isCancelled { return }
                failedTypes += 1
            }
        }
        guard current == generation else { return }
        let fresh = decoded.filter { fetchedIDs.insert($0.id).inserted }
        if mediaType == "animation" {
            items += fresh.filter { ($0.sourceGenres ?? []).contains { genre in
                let text = genre.lowercased()
                return text.contains("animation") || text.contains("anime") || text.contains("كرتون") || text.contains("كارتون") || text.contains("انيمي") || text.contains("أنيمي") || text.contains("انمي") || text.contains("أنمي") || text.contains("رسوم")
            } }
        } else { items += fresh }
        if failedTypes > 0 {
            message = decoded.isEmpty ? "تعذّر البحث في المصدر. أعد المحاولة من هذه الشبكة." : "وصلت بعض النتائج، لكن تعذّر طلب أحد الأقسام. أعد المحاولة لاستكمالها."
            ended = false
            retryingPartialPage = true
        } else {
            ended = decoded.isEmpty || (!retryingPartialPage && fresh.isEmpty)
            retryingPartialPage = false
            page += 1
        }
    }
    nonisolated static func cleanQuery(_ value: String) -> String {
        let invisible: Set<UInt32> = [0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069, 0x0640]
        let scalars = value.precomposedStringWithCompatibilityMapping.unicodeScalars.filter { !invisible.contains($0.value) }
        let cleaned = String(String.UnicodeScalarView(scalars))
        return cleaned.split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }

}


enum TitleSearch {
    static func normalized(_ value: String) -> String {
        let text = LibraryBrowseModel.cleanQuery(value).folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "ar"))
            .replacingOccurrences(of: "أ", with: "ا").replacingOccurrences(of: "إ", with: "ا").replacingOccurrences(of: "آ", with: "ا")
            .replacingOccurrences(of: "ى", with: "ي").replacingOccurrences(of: "ı", with: "i")
        return text.unicodeScalars.map { CharacterSet.alphanumerics.contains($0) ? String($0) : " " }.joined().split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }
    static func variants(_ query: String) -> [String] {
        let cleaned = LibraryBrowseModel.cleanQuery(query)
        let groups = [
            ["Yeraltı", "Yeralti", "تحت الأرض", "تحت الارض"],
            ["Çukur", "Cukur", "الحفرة", "The Pit"],
            ["Hudutsuz Sevda", "حب بلا حدود", "Boundless Love"]
        ]
        let key = normalized(cleaned)
        let group = groups.first { $0.contains { normalized($0) == key } }
        let fallback = normalized(cleaned)
        let candidates = group.map { [cleaned] + $0 } ?? (fallback == cleaned.lowercased() ? [cleaned] : [cleaned, fallback])
        // Deduplicate network requests without removing Turkish diacritics.
        var seen = Set<String>()
        return candidates.filter { !$0.isEmpty && seen.insert($0.lowercased()).inserted }.prefix(3).map { $0 }
    }
    static func isAnimation(_ show: Show) -> Bool {
        return (show.sourceGenres ?? [show.category]).contains { genre in
            let value = normalized(genre)
            return ["animation", "anime", "كرتون", "كارتون", "انمي", "انيمي", "رسوم"].contains { value.contains($0) }
        }
    }
    static func score(_ show: Show, query: String) -> Int {
        let needle = normalized(query)
        guard !needle.isEmpty else { return 0 }
        let aliases = [show.title] + (show.alternateTitles ?? [])
        return variants(query).flatMap { term in aliases.map { alias -> Int in
            let needle = normalized(term)
            let title = normalized(alias)
            if title == needle { return 4 }
            if title.hasPrefix(needle) { return 3 }
            if title.contains(needle) { return 2 }
            return needle.split(separator: " ").allSatisfy { title.contains($0) } ? 1 : 0
        } }.max() ?? 0
    }
}

struct LibraryExplorerView: View {
    var initialType = "movie"
    @StateObject private var model = LibraryBrowseModel()
    @EnvironmentObject private var catalog: Catalog
    @State private var query = ""
    @State private var mediaType = "movie"
    @State private var appliedQuery = ""
    @State private var appliedType = "movie"
    @State private var languages: [LibraryLanguage] = []
    @State private var languageID = ""
    @State private var searchRevision = 0
    init(initialType: String = "movie") {
        self.initialType = initialType
        _mediaType = State(initialValue: initialType)
        _appliedType = State(initialValue: initialType)
    }
    private var displayed: [Show] {
        let typed = LibraryBrowseModel.cleanQuery(query)
        var seen = Set<String>()
        let cached = catalog.shows.filter { typed.isEmpty ? (mediaType == "animation" && TitleSearch.isAnimation($0)) : TitleSearch.score($0, query: typed) > 0 }
        let combined = (model.items + cached).filter { show in
            let matchesType = mediaType == "all" || (mediaType == "movie" && show.sourceKind == "1") || (mediaType == "series" && show.sourceKind == "2") || (mediaType == "animation" && TitleSearch.isAnimation(show))
            return seen.insert(show.id).inserted && matchesType && (languageID.isEmpty || show.sourceLanguageID == languageID)
        }
        return typed.isEmpty ? combined : combined.sorted { TitleSearch.score($0, query: typed) > TitleSearch.score($1, query: typed) }
    }
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 22) {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(mediaType == "all" ? "البحث الشامل" : mediaType == "series" ? "عالم المسلسلات" : mediaType == "animation" ? "عالم الكرتون" : "مكتبة الأفلام").font(.largeTitle.bold())
                        Text("تتجدد الأعمال تلقائيًا أثناء التصفح").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: mediaType == "series" ? "tv" : "film.stack").font(.title).foregroundStyle(Theme.accent)
                }
                HStack {
                    TextField("اسم الفيلم أو المسلسل بالعربي أو الإنكليزي", text: $query)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.search).onSubmit { searchRevision += 1 }
                    if !query.isEmpty { Button { query = "" } label: { Image(systemName: "xmark.circle.fill") } }
                    Button { searchRevision += 1 } label: { Image(systemName: "magnifyingglass") }.accessibilityLabel("ابدأ البحث")
                }.padding(14).background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                if query.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack { ForEach(["تحت الأرض", "الحفرة", "حب بلا حدود"], id: \.self) { title in
                            Button(title) { query = title }.buttonStyle(.bordered)
                        } }
                    }
                    Text("اختصارات بحث بالأسماء العربية والتركية؛ التوفر حسب رد المصدر.").font(.caption).foregroundStyle(.secondary)
                }
                Picker("نوع العرض", selection: $mediaType) {
                    Text("الكل").tag("all")
                    Text("أفلام").tag("movie")
                    Text("مسلسلات").tag("series")
                    Text("كرتون").tag("animation")
                }.pickerStyle(.segmented)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        languageChip("كل اللغات", id: "")
                        ForEach(languages) { language in languageChip(language.title, id: language.id) }
                    }
                }
                Text(query.isEmpty ? "\(model.items.count) عمل متاح في الصفحات التي وصلت" : "\(displayed.count) نتيجة وصلت من المصدر والأعمال المحفوظة").font(.caption).foregroundStyle(.secondary)
                if let message = model.message {
                    Text(message).font(.footnote).foregroundStyle(.orange)
                    Button("إعادة المحاولة") { Task { await model.more() } }
                }
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 24) {
                    ForEach(displayed) { show in
                        NavigationLink { DetailView(show: show) } label: { PosterCard(show: show) }.buttonStyle(.plain)
                    }
                }
                if !model.ended && model.message == nil && LibraryBrowseModel.cleanQuery(query) == appliedQuery && mediaType == appliedType {
                    ProgressView("جلب المزيد من الأعمال…").frame(maxWidth: .infinity).padding()
                        .task(id: model.page) { await model.more() }
                } else if model.ended && displayed.isEmpty {
                    Text(query.isEmpty ? "لا توجد نتائج بهذه اللغة في الصفحات التي أعادها المصدر." : "لم يصل عنوان مطابق. افتح فحص البحث أدناه؛ سيختبر الاسم المكتوب نفسه.").font(.footnote).foregroundStyle(.secondary)
                }
                NavigationLink(query.isEmpty ? "فحص المصدر والبحث" : "فحص البحث عن: " + query) { SourceDiagnosticsView(searchQuery: LibraryBrowseModel.cleanQuery(query)) }.font(.footnote)
            }.padding(20)
        }.background(Theme.background).navigationBarTitleDisplayMode(.inline)
            .onChange(of: query) { value in
                if !LibraryBrowseModel.cleanQuery(value).isEmpty { mediaType = "all"; languageID = ""; UserDefaults.standard.set(LibraryBrowseModel.cleanQuery(value), forKey: "lastSearchQuery") }
            }
            .task(id: mediaType + "|" + query + "|" + String(searchRevision)) {
                do { try await Task.sleep(nanoseconds: 450_000_000) } catch { return }
                appliedQuery = LibraryBrowseModel.cleanQuery(query)
                appliedType = mediaType
                await model.reset(query: appliedQuery, mediaType: mediaType)
            }
            .task { await loadLanguages() }
            .onReceive(model.$items) { items in
                guard !items.isEmpty else { return }
                var known = Set(catalog.shows.map(\.id))
                catalog.shows += items.filter { known.insert($0.id).inserted }
            }
    }
    private func languageChip(_ title: String, id: String) -> some View {
        Button { languageID = id } label: {
            Text(title).font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 11)
                .background(languageID == id ? Theme.accent : Color.white.opacity(0.06), in: Capsule())
                .foregroundStyle(.white)
        }
    }
    @MainActor private func loadLanguages() async {
        do {
            let data = try await LibraryAPI.read(URL(string: "https://cinemana.shabakaty.com/api/android/categories")!)
            guard let rows = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return }
            var seen = Set<String>()
            languages = rows.flatMap { $0["langArray"] as? [[String: Any]] ?? [] }.compactMap { row in
                guard let id = row["langNb"] as? String, let title = row["lang_ar_title"] as? String, seen.insert(id).inserted else { return nil }
                return LibraryLanguage(id: id, title: title)
            }.sorted {
                let priority = ["التركية", "الإنجليزية", "الانجليزية", "العربية", "الكورية", "اليابانية"]
                let left = priority.firstIndex(of: $0.title) ?? 100
                let right = priority.firstIndex(of: $1.title) ?? 100
                return left == right ? $0.title < $1.title : left < right
            }
        } catch { }
    }
}
struct LibraryLanguage: Identifiable { let id: String; let title: String }

struct RemoteSeriesEpisode: Identifiable {
    let id: String
    let season: Int
    let number: Int
    let title: String
}

struct RemoteSeriesEpisodesView: View {
    let sourceID: String
    let show: Show
    @State private var episodes: [RemoteSeriesEpisode] = []
    @State private var season = 1
    @State private var loading = true
    @State private var message: String?
    @State private var selectedEpisode: RemoteSeriesEpisode?
    private var seasons: [Int] { Array(Set(episodes.map(\.season))).sorted() }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if loading { ProgressView("تحميل المواسم والحلقات…") }
            else if episodes.isEmpty {
                if let message = message { Text(message).font(.footnote).foregroundStyle(.secondary) }
                PlaybackOptionsView(sourceID: sourceID, show: show)
            } else {
                Text("المواسم والحلقات").font(.title2.bold())
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(seasons, id: \.self) { value in
                            Button { season = value } label: {
                                Text("الموسم \(value)").font(.subheadline.bold()).padding(.horizontal, 18).padding(.vertical, 12)
                                    .background(value == season ? Theme.accent : Color.white.opacity(0.06), in: Capsule())
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                }
                Text("\(episodes.filter { $0.season == season }.count) حلقة في هذا الموسم").font(.caption).foregroundStyle(.secondary)
                ForEach(episodes.filter { $0.season == season }.sorted { $0.number < $1.number }) { episode in
                    Button { selectedEpisode = episode } label: {
                        HStack {
                            Text(String(format: "%02d", episode.number)).font(.system(size: 22, weight: .black, design: .rounded))
                                .frame(width: 55, height: 62).background(LinearGradient(colors: [.blue.opacity(0.45), .purple.opacity(0.4)], startPoint: .top, endPoint: .bottom), in: RoundedRectangle(cornerRadius: 14))
                            VStack(alignment: .leading, spacing: 6) {
                                Text(episode.title).font(.headline).foregroundStyle(.white)
                                Text("الموسم \(episode.season) • اختر الجودة للمشاهدة").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "play.circle.fill").font(.title).foregroundStyle(Theme.accent)
                        }.padding(12).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 20))
                    }
                }
            }
        }.task(id: sourceID) { await load() }
            .sheet(item: $selectedEpisode) { episode in
                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 22) {
                            PlaybackOptionsView(sourceID: episode.id, show: episodeShow(episode))
                            NavigationLink("فحص ملفات هذه الحلقة") { SourceDiagnosticsView(selectedID: episode.id) }
                        }.padding(20)
                    }.background(Theme.background).navigationTitle(episode.title).navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { selectedEpisode = nil } } }
                }
            }
    }
    private func episodeShow(_ episode: RemoteSeriesEpisode) -> Show {
        Show(id: show.id, title: show.title + " — " + episode.title, category: show.category,
             synopsis: show.synopsis, rating: show.rating, symbol: show.symbol, palette: show.palette,
             posterURL: show.posterURL, episodes: [], sourceID: episode.id, sourceKind: "1", sourceLanguageID: show.sourceLanguageID, sourceGenres: show.sourceGenres)
    }
    @MainActor private func load() async {
        guard !sourceID.isEmpty, sourceID.utf8.allSatisfy({ (48...57).contains($0) }) else { return }
        loading = true
        defer { loading = false }
        do {
            let url = URL(string: "https://cinemana.shabakaty.com/api/android/videoSeason/id/" + sourceID)!
            let data = try await LibraryAPI.read(url)
            guard let rows = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw LibraryAPI.APIError.response }
            var seen = Set<String>()
            episodes = rows.compactMap { row in
                func text(_ key: String) -> String {
                    if let s = row[key] as? String { return s }
                    if let n = row[key] as? NSNumber { return n.stringValue }
                    return ""
                }
                let id = text("nb")
                guard !id.isEmpty, id.utf8.allSatisfy({ (48...57).contains($0) }), seen.insert(id).inserted,
                      let season = Int(text("season")), let number = Int(text("episodeNummer")) else { return nil }
                return RemoteSeriesEpisode(id: id, season: season, number: number, title: "الحلقة \(number)")
            }
            season = seasons.first ?? 1
        } catch {
            if !Task.isCancelled { message = "لم نتمكن من تحميل الحلقات؛ يمكنك تجربة خيارات العمل المباشرة." }
        }
    }
}
