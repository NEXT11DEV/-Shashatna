import SwiftUI
import Foundation
import Combine

enum LibraryAPI {
    static func read(_ address: URL) async throws -> Data {
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil
        config.urlCredentialStorage = nil
        config.timeoutIntervalForRequest = 20
        config.timeoutIntervalForResource = 30
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: address, cachePolicy: .reloadIgnoringLocalCacheData)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (file, response) = try await session.download(for: request)
        defer { try? FileManager.default.removeItem(at: file) }
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode), http.url?.host == address.host else { throw APIError.response }
        let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
        guard ((attrs[.size] as? NSNumber)?.intValue ?? 0) <= 5_000_000 else { throw APIError.response }
        return try Data(contentsOf: file)
    }
    enum APIError: Error { case response }
}

@MainActor final class LibraryBrowseModel: ObservableObject {
    @Published var items: [Show] = []
    @Published var loading = false
    @Published var message: String?
    @Published var ended = false
    private var query = ""
    private var page = 1
    private var generation = 0

    func reset(query: String) async {
        generation += 1
        self.query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        page = 1
        items = []
        ended = false
        loading = false
        await more()
    }

    func more() async {
        guard !loading, !ended else { return }
        let current = generation
        loading = true
        message = nil
        defer { if current == generation { loading = false } }
        do {
            var components = URLComponents(string: "https://cinemana.shabakaty.com/api/android/AdvancedSearch")!
            components.queryItems = [URLQueryItem(name: "videoTitle", value: query), URLQueryItem(name: "page", value: String(page))]
            guard let url = components.url else { throw LibraryAPI.APIError.response }
            let data = try await LibraryAPI.read(url)
            let decoded = try Catalog.decodeShabakaty(data)
            guard current == generation else { return }
            let known = Set(items.map(\.id))
            let fresh = decoded.filter { !known.contains($0.id) }
            items += fresh
            ended = decoded.isEmpty || fresh.isEmpty
            page += 1
        } catch {
            guard current == generation, !Task.isCancelled else { return }
            message = "تعذّر تحميل هذه الصفحة من المصدر. جرّب البحث بعنوان محدد أو أرسل تقرير فحص المصدر."
        }
    }
}

struct LibraryExplorerView: View {
    @StateObject private var model = LibraryBrowseModel()
    @EnvironmentObject private var catalog: Catalog
    @State private var query = ""
    @State private var filter = "الكل"
    @State private var appliedQuery = ""
    private var displayed: [Show] {
        model.items.filter { filter == "الكل" || (filter == "أفلام" ? $0.sourceKind == "1" : $0.sourceKind != "1") }
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text("اكتشف حكايتك القادمة").font(.title.bold())
                Text("تصفح صفحات المصدر، أو ابحث عن عنوان في المكتبة.").font(.subheadline).foregroundStyle(.secondary)
                Picker("نوع العرض", selection: $filter) {
                    Text("الكل").tag("الكل")
                    Text("أفلام").tag("أفلام")
                    Text("أعمال أخرى").tag("أعمال أخرى")
                }.pickerStyle(.segmented)
                HStack {
                    Text("\(model.items.count) عمل محمّل").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    if !appliedQuery.isEmpty { Text("بحث: \(appliedQuery)").font(.caption).lineLimit(1) }
                }
                if let message = model.message { Text(message).font(.footnote).foregroundStyle(.orange) }
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 24) {
                    ForEach(displayed) { show in
                        NavigationLink { DetailView(show: show) } label: { PosterCard(show: show) }.buttonStyle(.plain)
                    }
                }
                if model.loading { ProgressView("تحميل الأعمال…").frame(maxWidth: .infinity) }
                else if !model.ended {
                    Button { Task { await model.more() } } label: {
                        Label(model.message == nil ? "تحميل المزيد" : "إعادة المحاولة", systemImage: "plus.circle")
                            .frame(maxWidth: .infinity).padding(12)
                    }.buttonStyle(.borderedProminent)
                } else {
                    Text(model.items.isEmpty ? "لم يرجع المصدر نتائج لهذا البحث." : "انتهت الصفحات المتاحة لهذا الطلب.")
                        .font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity)
                }
                NavigationLink("فحص اتصال المكتبة") { SourceDiagnosticsView() }.font(.footnote)
            }.padding(20)
        }.background(Theme.background).navigationTitle("استكشف").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "ابحث في مكتبة المصدر")
            .onSubmit(of: .search) { Task { appliedQuery = query; await model.reset(query: query) } }
            .task { if model.items.isEmpty { await model.reset(query: "") } }
            .onReceive(model.$items) { items in
                guard !items.isEmpty else { return }
                var known = Set(catalog.shows.map(\.id))
                catalog.shows += items.filter { known.insert($0.id).inserted }
            }
    }
}

struct RemoteSeriesEpisode: Identifiable {
    let id: String
    let season: Int
    let number: Int
    let title: String
}

struct RemoteSeriesEpisodesView: View {
    let sourceID: String
    let show: Show
    @State private var episodes: [RemoteSeriesEpisode] = []
    @State private var season = 1
    @State private var loading = true
    @State private var message: String?
    @State private var selectedEpisode: RemoteSeriesEpisode?
    private var seasons: [Int] { Array(Set(episodes.map(\.season))).sorted() }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if loading { ProgressView("تحميل المواسم والحلقات…") }
            else if episodes.isEmpty {
                if let message = message { Text(message).font(.footnote).foregroundStyle(.secondary) }
                PlaybackOptionsView(sourceID: sourceID, show: show)
            } else {
                Text("المواسم والحلقات").font(.title2.bold())
                Picker("الموسم", selection: $season) {
                    ForEach(seasons, id: \.self) { Text("الموسم \($0)").tag($0) }
                }.pickerStyle(.menu)
                ForEach(episodes.filter { $0.season == season }.sorted { $0.number < $1.number }) { episode in
                    Button { selectedEpisode = episode } label: {
                        HStack {
                            Image(systemName: "play.circle.fill").font(.title2)
                            Text(episode.title).font(.headline)
                            Spacer()
                            Text("\(episode.number)").font(.caption)
                        }.padding(14).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
                    }
                }
            }
        }.task(id: sourceID) { await load() }
            .sheet(item: $selectedEpisode) { episode in
                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 22) {
                            PlaybackOptionsView(sourceID: episode.id, show: episodeShow(episode))
                            NavigationLink("فحص ملفات هذه الحلقة") { SourceDiagnosticsView(selectedID: episode.id) }
                        }.padding(20)
                    }.background(Theme.background).navigationTitle(episode.title).navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { selectedEpisode = nil } } }
                }
            }
    }
    private func episodeShow(_ episode: RemoteSeriesEpisode) -> Show {
        Show(id: show.id, title: show.title + " — " + episode.title, category: show.category,
             synopsis: show.synopsis, rating: show.rating, symbol: show.symbol, palette: show.palette,
             posterURL: show.posterURL, episodes: [], sourceID: episode.id, sourceKind: "1")
    }
    @MainActor private func load() async {
        guard !sourceID.isEmpty, sourceID.utf8.allSatisfy({ (48...57).contains($0) }) else { return }
        loading = true
        defer { loading = false }
        do {
            let url = URL(string: "https://cinemana.shabakaty.com/api/android/videoSeason/id/" + sourceID)!
            let data = try await LibraryAPI.read(url)
            guard let rows = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw LibraryAPI.APIError.response }
            var seen = Set<String>()
            episodes = rows.compactMap { row in
                func text(_ key: String) -> String {
                    if let s = row[key] as? String { return s }
                    if let n = row[key] as? NSNumber { return n.stringValue }
                    return ""
                }
                let id = text("nb")
                guard !id.isEmpty, id.utf8.allSatisfy({ (48...57).contains($0) }), seen.insert(id).inserted,
                      let season = Int(text("season")), let number = Int(text("episodeNummer")) else { return nil }
                return RemoteSeriesEpisode(id: id, season: season, number: number, title: "الحلقة \(number)")
            }
            season = seasons.first ?? 1
        } catch {
            if !Task.isCancelled { message = "لم نتمكن من تحميل الحلقات؛ يمكنك تجربة خيارات العمل المباشرة." }
        }
    }
}
