import SwiftUI
import Foundation
import Combine

enum LibraryAPI {
    static func read(_ address: URL) async throws -> Data {
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil
        config.urlCredentialStorage = nil
        config.timeoutIntervalForRequest = 20
        config.timeoutIntervalForResource = 30
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: address, cachePolicy: .reloadIgnoringLocalCacheData)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (file, response) = try await session.download(for: request)
        defer { try? FileManager.default.removeItem(at: file) }
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode), http.url?.host == address.host else { throw APIError.response }
        let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
        guard ((attrs[.size] as? NSNumber)?.intValue ?? 0) <= 5_000_000 else { throw APIError.response }
        return try Data(contentsOf: file)
    }
    enum APIError: Error { case response }
}

@MainActor final class LibraryBrowseModel: ObservableObject {
    @Published var items: [Show] = []
    @Published var loading = false
    @Published var message: String?
    @Published var ended = false
    private var query = ""
    private var mediaType = "movie"
    @Published private(set) var page = 1
    private var generation = 0
    private var fetchedIDs = Set<String>()

    func reset(query: String, mediaType: String = "movie") async {
        generation += 1
        self.query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        self.mediaType = mediaType
        page = 1
        items = []
        fetchedIDs = []
        ended = false
        loading = false
        await more()
    }

    func more() async {
        guard !loading, !ended else { return }
        let current = generation
        loading = true
        message = nil
        defer { if current == generation { loading = false } }
        do {
            let types = mediaType == "animation" ? ["movie", "series"] : [mediaType]
            var decoded: [Show] = []
            for type in types {
                var components = URLComponents(string: "https://cinemana.shabakaty.com/api/android/AdvancedSearch")!
                components.queryItems = [URLQueryItem(name: "videoTitle", value: query), URLQueryItem(name: "type", value: type), URLQueryItem(name: "page", value: String(page))]
                guard let url = components.url else { throw LibraryAPI.APIError.response }
                let data = try await LibraryAPI.read(url)
                decoded += try Catalog.decodeShabakaty(data)
            }
            guard current == generation else { return }
            let fresh = decoded.filter { fetchedIDs.insert($0.id).inserted }
            if mediaType == "animation" {
                items += fresh.filter { ($0.sourceGenres ?? []).contains { genre in
                    let text = genre.lowercased()
                    return text.contains("animation") || text.contains("anime") || text.contains("كرتون") || text.contains("كارتون") || text.contains("انيمي") || text.contains("أنيمي") || text.contains("رسوم")
                } }
            } else { items += fresh }
            ended = decoded.isEmpty || fresh.isEmpty
            page += 1
        } catch {
            guard current == generation, !Task.isCancelled else { return }
            message = "تعذّر تحميل هذه الصفحة من المصدر. جرّب البحث بعنوان محدد أو أرسل تقرير فحص المصدر."
        }
    }
}

struct LibraryExplorerView: View {
    var initialType = "movie"
    @StateObject private var model = LibraryBrowseModel()
    @EnvironmentObject private var catalog: Catalog
    @State private var query = ""
    @State private var mediaType = "movie"
    @State private var appliedQuery = ""
    @State private var languages: [LibraryLanguage] = []
    @State private var languageID = ""
    init(initialType: String = "movie") {
        self.initialType = initialType
        _mediaType = State(initialValue: initialType)
    }
    private var displayed: [Show] { model.items.filter { languageID.isEmpty || $0.sourceLanguageID == languageID } }
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 22) {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(mediaType == "series" ? "عالم المسلسلات" : mediaType == "animation" ? "عالم الكرتون" : "مكتبة الأفلام").font(.largeTitle.bold())
                        Text("تتجدد الأعمال تلقائيًا أثناء التصفح").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: mediaType == "series" ? "tv" : "film.stack").font(.title).foregroundStyle(Theme.accent)
                }
                Picker("نوع العرض", selection: $mediaType) {
                    Text("أفلام").tag("movie")
                    Text("مسلسلات").tag("series")
                    Text("كرتون").tag("animation")
                }.pickerStyle(.segmented)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        languageChip("كل اللغات", id: "")
                        ForEach(languages) { language in languageChip(language.title, id: language.id) }
                    }
                }
                Text("\(model.items.count) عمل متاح في الصفحات التي وصلت").font(.caption).foregroundStyle(.secondary)
                if let message = model.message {
                    Text(message).font(.footnote).foregroundStyle(.orange)
                    Button("إعادة المحاولة") { Task { await model.more() } }
                }
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 24) {
                    ForEach(displayed) { show in
                        NavigationLink { DetailView(show: show) } label: { PosterCard(show: show) }.buttonStyle(.plain)
                    }
                }
                if !model.ended && model.message == nil {
                    ProgressView("جلب المزيد من الأعمال…").frame(maxWidth: .infinity).padding()
                        .task(id: model.page) { await model.more() }
                } else if model.ended && displayed.isEmpty {
                    Text("لا توجد نتائج بهذه اللغة في الصفحات التي أعادها المصدر.").font(.footnote).foregroundStyle(.secondary)
                }
                NavigationLink("فحص أقسام المصدر") { SourceDiagnosticsView() }.font(.footnote)
            }.padding(20)
        }.background(Theme.background).navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "ابحث عن فيلم أو مسلسل")
            .onSubmit(of: .search) { Task { appliedQuery = query; await model.reset(query: query, mediaType: mediaType) } }
            .onChange(of: mediaType) { value in Task { await model.reset(query: appliedQuery, mediaType: value) } }
            .task {
                if model.items.isEmpty { await model.reset(query: "", mediaType: initialType) }
                await loadLanguages()
            }
            .onReceive(model.$items) { items in
                guard !items.isEmpty else { return }
                var known = Set(catalog.shows.map(\.id))
                catalog.shows += items.filter { known.insert($0.id).inserted }
            }
    }
    private func languageChip(_ title: String, id: String) -> some View {
        Button { languageID = id } label: {
            Text(title).font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 11)
                .background(languageID == id ? Theme.accent : Color.white.opacity(0.06), in: Capsule())
                .foregroundStyle(.white)
        }
    }
    @MainActor private func loadLanguages() async {
        do {
            let data = try await LibraryAPI.read(URL(string: "https://cinemana.shabakaty.com/api/android/categories")!)
            guard let rows = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return }
            var seen = Set<String>()
            languages = rows.flatMap { $0["langArray"] as? [[String: Any]] ?? [] }.compactMap { row in
                guard let id = row["langNb"] as? String, let title = row["lang_ar_title"] as? String, seen.insert(id).inserted else { return nil }
                return LibraryLanguage(id: id, title: title)
            }.sorted {
                let priority = ["التركية", "الإنجليزية", "الانجليزية", "العربية", "الكورية", "اليابانية"]
                let left = priority.firstIndex(of: $0.title) ?? 100
                let right = priority.firstIndex(of: $1.title) ?? 100
                return left == right ? $0.title < $1.title : left < right
            }
        } catch { }
    }
}
struct LibraryLanguage: Identifiable { let id: String; let title: String }

struct RemoteSeriesEpisode: Identifiable {
    let id: String
    let season: Int
    let number: Int
    let title: String
}

struct RemoteSeriesEpisodesView: View {
    let sourceID: String
    let show: Show
    @State private var episodes: [RemoteSeriesEpisode] = []
    @State private var season = 1
    @State private var loading = true
    @State private var message: String?
    @State private var selectedEpisode: RemoteSeriesEpisode?
    private var seasons: [Int] { Array(Set(episodes.map(\.season))).sorted() }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if loading { ProgressView("تحميل المواسم والحلقات…") }
            else if episodes.isEmpty {
                if let message = message { Text(message).font(.footnote).foregroundStyle(.secondary) }
                PlaybackOptionsView(sourceID: sourceID, show: show)
            } else {
                Text("المواسم والحلقات").font(.title2.bold())
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(seasons, id: \.self) { value in
                            Button { season = value } label: {
                                Text("الموسم \(value)").font(.subheadline.bold()).padding(.horizontal, 18).padding(.vertical, 12)
                                    .background(value == season ? Theme.accent : Color.white.opacity(0.06), in: Capsule())
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                }
                Text("\(episodes.filter { $0.season == season }.count) حلقة في هذا الموسم").font(.caption).foregroundStyle(.secondary)
                ForEach(episodes.filter { $0.season == season }.sorted { $0.number < $1.number }) { episode in
                    Button { selectedEpisode = episode } label: {
                        HStack {
                            Text(String(format: "%02d", episode.number)).font(.system(size: 22, weight: .black, design: .rounded))
                                .frame(width: 55, height: 62).background(LinearGradient(colors: [.blue.opacity(0.45), .purple.opacity(0.4)], startPoint: .top, endPoint: .bottom), in: RoundedRectangle(cornerRadius: 14))
                            VStack(alignment: .leading, spacing: 6) {
                                Text(episode.title).font(.headline).foregroundStyle(.white)
                                Text("الموسم \(episode.season) • اختر الجودة للمشاهدة").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "play.circle.fill").font(.title).foregroundStyle(Theme.accent)
                        }.padding(12).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 20))
                    }
                }
            }
        }.task(id: sourceID) { await load() }
            .sheet(item: $selectedEpisode) { episode in
                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 22) {
                            PlaybackOptionsView(sourceID: episode.id, show: episodeShow(episode))
                            NavigationLink("فحص ملفات هذه الحلقة") { SourceDiagnosticsView(selectedID: episode.id) }
                        }.padding(20)
                    }.background(Theme.background).navigationTitle(episode.title).navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { selectedEpisode = nil } } }
                }
            }
    }
    private func episodeShow(_ episode: RemoteSeriesEpisode) -> Show {
        Show(id: show.id, title: show.title + " — " + episode.title, category: show.category,
             synopsis: show.synopsis, rating: show.rating, symbol: show.symbol, palette: show.palette,
             posterURL: show.posterURL, episodes: [], sourceID: episode.id, sourceKind: "1", sourceLanguageID: show.sourceLanguageID, sourceGenres: show.sourceGenres)
    }
    @MainActor private func load() async {
        guard !sourceID.isEmpty, sourceID.utf8.allSatisfy({ (48...57).contains($0) }) else { return }
        loading = true
        defer { loading = false }
        do {
            let url = URL(string: "https://cinemana.shabakaty.com/api/android/videoSeason/id/" + sourceID)!
            let data = try await LibraryAPI.read(url)
            guard let rows = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw LibraryAPI.APIError.response }
            var seen = Set<String>()
            episodes = rows.compactMap { row in
                func text(_ key: String) -> String {
                    if let s = row[key] as? String { return s }
                    if let n = row[key] as? NSNumber { return n.stringValue }
                    return ""
                }
                let id = text("nb")
                guard !id.isEmpty, id.utf8.allSatisfy({ (48...57).contains($0) }), seen.insert(id).inserted,
                      let season = Int(text("season")), let number = Int(text("episodeNummer")) else { return nil }
                return RemoteSeriesEpisode(id: id, season: season, number: number, title: "الحلقة \(number)")
            }
            season = seasons.first ?? 1
        } catch {
            if !Task.isCancelled { message = "لم نتمكن من تحميل الحلقات؛ يمكنك تجربة خيارات العمل المباشرة." }
        }
    }
}
