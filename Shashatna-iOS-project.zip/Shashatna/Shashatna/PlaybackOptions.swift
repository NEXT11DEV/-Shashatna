import SwiftUI
import Foundation
import AVKit
import UIKit
import Combine

// HUB uses the same media paths on these alternate hosts. Preserve signed queries.
enum CinemanaMediaRoute {
    static func candidates(_ url: URL, mode: String? = nil) -> [URL] {
        let pairs = ["cdn.shabakaty.com": "cdn.cee.buzz",
                     "cnth2.shabakaty.com": "cnth2.cee.buzz",
                     "cnth.shabakaty.com": "cnth.cee.buzz"]
        guard url.scheme?.lowercased() == "https", url.user == nil, url.password == nil,
              let host = url.host?.lowercased(),
              let original = pairs[host] != nil ? host : pairs.first(where: { $0.value == host })?.key,
              let alternate = pairs[original], var parts = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return [url] }
        let selected = mode ?? UserDefaults.standard.string(forKey: "cinemanaConnectionMode") ?? "auto"
        let hosts = selected == "shabakaty" ? [original, alternate] : [alternate, original]
        return hosts.compactMap { host in parts.host = host; return parts.url }
    }
}

// Keep one AVPlayer across inline, full screen, rotation and PiP.
@MainActor final class ShashatnaPlayerControls: NSObject, ObservableObject, AVPlayerViewControllerDelegate {
    let player: AVPlayer
    @Published var failureMessage: String?
    private var mediaCandidates: [URL] = []
    private var candidateIndex = 0
    private var startupWatchdog: Task<Void, Never>?
    private var itemObservation: NSKeyValueObservation?
    private var stalledSince: Date?
    private var resumeAfterReplacement = 0.0
    @Published var pipActive = false
    @Published var pipMessage: String?
    @Published var isPlaying = false
    @Published var waiting = false
    @Published var seeking = false
    @Published var seconds = 0.0
    @Published var duration = 0.0
    private var wantsPlayback = false
    private var seekGeneration = 0
    private var pendingSeek: Double?
    private var playbackObservation: NSKeyValueObservation?
    private var timeObserver: Any?
    init(player: AVPlayer, sourceURL: URL? = nil) {
        self.player = player
        self.mediaCandidates = sourceURL.map { CinemanaMediaRoute.candidates($0) } ?? []
        super.init()
        playbackObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            let status = player.timeControlStatus
            Task { @MainActor [weak self] in
                self?.isPlaying = status != .paused
                self?.waiting = status == .waitingToPlayAtSpecifiedRate
            }
        }
        observeItem()
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.25, preferredTimescale: 600), queue: .main) { [weak self] time in
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                if self.player.timeControlStatus == .waitingToPlayAtSpecifiedRate {
                    if self.stalledSince == nil { self.stalledSince = Date() }
                    if let since = self.stalledSince, Date().timeIntervalSince(since) > 25, self.failureMessage == nil {
                        self.failureMessage = "تأخر تحميل الفيديو. أعد المحاولة أو ارجع واختر جودة أخرى."
                    }
                } else {
                    self.stalledSince = nil
                    if self.player.timeControlStatus == .playing { self.failureMessage = nil }
                }
                let length = self.player.currentItem?.duration.seconds ?? 0
                self.duration = length.isFinite && length > 0 ? length : 0
                if !self.seeking { self.seconds = time.seconds.isFinite ? max(0, time.seconds) : 0 }
            }
        }
    }
    deinit {
        startupWatchdog?.cancel()
        if let token = timeObserver { player.removeTimeObserver(token) }
    }
    private func observeItem() {
        startupWatchdog?.cancel()
        startupWatchdog = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 25_000_000_000)
            guard !Task.isCancelled, let self = self,
                  self.player.timeControlStatus == .waitingToPlayAtSpecifiedRate,
                  self.failureMessage == nil else { return }
            self.failureMessage = "تأخر تحميل الفيديو. أعد المحاولة أو ارجع واختر جودة أخرى."
        }
        itemObservation = player.currentItem?.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            Task { @MainActor [weak self, weak item] in
                guard let self = self, let item = item, item === self.player.currentItem else { return }
                if item.status == .failed { self.handleFailure() }
                if item.status == .readyToPlay, self.resumeAfterReplacement > 0 {
                    let position = self.resumeAfterReplacement
                    self.resumeAfterReplacement = 0
                    self.player.seek(to: CMTime(seconds: position, preferredTimescale: 600))
                }
            }
        }
    }
    func handleFailure() {
        if candidateIndex + 1 < mediaCandidates.count {
            candidateIndex += 1
            replaceItem()
            return
        }
        let error = (player.currentItem?.error ?? player.error) as NSError?
        let host = mediaCandidates.indices.contains(candidateIndex) ? mediaCandidates[candidateIndex].host ?? "" : ""
        let code = error.map { "\($0.domain): \($0.code)" } ?? "AVPlayer"
        let http = player.currentItem?.errorLog()?.events.last?.errorStatusCode
        failureMessage = "تعذّر تحميل الفيديو. جرّب جودة أخرى أو أعد فتح الحلقة لتجديد الرابط.\n\(host) • \(code)" + (http.map { " • status \($0)" } ?? "")
        player.pause()
        waiting = false
    }
    func retry() {
        guard !mediaCandidates.isEmpty else { return }
        candidateIndex = 0
        replaceItem()
    }
    private func replaceItem() {
        let position = player.currentTime().seconds
        if position.isFinite && position > 0 { resumeAfterReplacement = position }
        itemObservation = nil
        failureMessage = nil
        stalledSince = nil
        seeking = false
        pendingSeek = nil
        seekGeneration += 1
        player.replaceCurrentItem(with: AVPlayerItem(url: mediaCandidates[candidateIndex]))
        observeItem()
        player.play()
    }
    func togglePlayback() {
        let playing = seeking ? wantsPlayback : player.timeControlStatus != .paused
        wantsPlayback = !playing
        if wantsPlayback { player.play() } else { player.pause() }
    }
    func skip(_ delta: Double) {
        let now = player.currentTime().seconds
        seek(to: (pendingSeek ?? (now.isFinite ? now : 0)) + delta)
    }
    func seek(to requested: Double) {
        guard requested.isFinite, let item = player.currentItem, item.status == .readyToPlay else { return }
        let length = item.duration.seconds
        let range = item.seekableTimeRanges.last?.timeRangeValue
        let lower = range.map { max(0, $0.start.seconds) } ?? 0
        let upper = length.isFinite && length > 0 ? length : range.map { CMTimeRangeGetEnd($0).seconds } ?? 0
        guard lower.isFinite, upper.isFinite, upper > lower else {
            pipMessage = "هذا البث لم يوفر مجال تقديم وترجيع بعد."
            return
        }
        if !seeking { wantsPlayback = player.timeControlStatus != .paused }
        let target = min(max(requested, lower), max(lower, upper - 0.05))
        seconds = target
        pendingSeek = target
        seeking = true
        seekGeneration += 1
        let generation = seekGeneration
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] finished in
            Task { @MainActor [weak self] in
                guard let self = self, generation == self.seekGeneration else { return }
                self.seeking = false
                self.pendingSeek = nil
                if finished && self.wantsPlayback { self.player.play() }
                if !finished { self.pipMessage = "لم يكتمل الانتقال؛ جرّب مرة ثانية بعد تحميل الفيديو." }
            }
        }
    }
    nonisolated func playerViewControllerDidStartPictureInPicture(_ playerViewController: AVPlayerViewController) {
        Task { @MainActor [weak self] in self?.pipActive = true }
    }
    nonisolated func playerViewControllerDidStopPictureInPicture(_ playerViewController: AVPlayerViewController) {
        Task { @MainActor [weak self] in self?.pipActive = false }
    }
    nonisolated func playerViewController(_ playerViewController: AVPlayerViewController, failedToStartPictureInPictureWithError error: Error) {
        Task { @MainActor [weak self] in self?.pipMessage = "تعذّر تشغيل صورة داخل صورة على هذا الجهاز." }
    }
    nonisolated func playerViewController(_ playerViewController: AVPlayerViewController, restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        completionHandler(true)
    }
}

@MainActor enum PlaybackOrientation {
    static func landscape() {
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first(where: { $0.activationState == .foregroundActive }) else { return }
        scene.windows.first(where: { $0.isKeyWindow })?.rootViewController?.setNeedsUpdateOfSupportedInterfaceOrientations()
        scene.requestGeometryUpdate(.iOS(interfaceOrientations: .landscape))
    }
}

// Use the system transport, scrubber, audio controls and PiP rather than a gesture overlay.
struct ShashatnaNativePlayer: UIViewControllerRepresentable {
    @ObservedObject var controls: ShashatnaPlayerControls
    var active = true
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.delegate = controls
        controller.showsPlaybackControls = true
        controller.allowsPictureInPicturePlayback = true
        controller.canStartPictureInPictureAutomaticallyFromInline = true
        controller.videoGravity = .resizeAspect
        controller.player = active ? controls.player : nil
        controller.loadViewIfNeeded()
        if let overlay = controller.contentOverlayView {
            let brand = UILabel()
            brand.font = .roundedBrandFont
            let name = "Shashatna"
            let colored = NSMutableAttributedString(string: name)
            for index in 0..<name.utf16.count {
                let progress = CGFloat(index) / CGFloat(name.utf16.count - 1)
                let color = UIColor(red: 0.15 + 0.45 * progress, green: 0.8 - 0.55 * progress, blue: 1, alpha: 1)
                colored.addAttribute(.foregroundColor, value: color, range: NSRange(location: index, length: 1))
            }
            brand.attributedText = colored
            brand.layer.shadowColor = UIColor.black.cgColor
            brand.layer.shadowOpacity = 0.8
            brand.layer.shadowRadius = 1
            brand.layer.shadowOffset = CGSize(width: 0, height: 1)
            brand.isUserInteractionEnabled = false
            brand.translatesAutoresizingMaskIntoConstraints = false
            overlay.addSubview(brand)
            NSLayoutConstraint.activate([
                brand.topAnchor.constraint(equalTo: overlay.safeAreaLayoutGuide.topAnchor, constant: 12),
                brand.trailingAnchor.constraint(equalTo: overlay.safeAreaLayoutGuide.trailingAnchor, constant: -12)
            ])
        }
        return controller
    }
    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        let target = active ? controls.player : nil
        if controller.player !== target { controller.player = target }
    }
    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: ()) {
        controller.delegate = nil
        controller.player = nil
    }
}

private extension UIFont {
    static var roundedBrandFont: UIFont {
        let font = UIFont.systemFont(ofSize: 12, weight: .bold)
        return font.fontDescriptor.withDesign(.rounded).map { UIFont(descriptor: $0, size: 12) } ?? font
    }
}

struct PlaybackTransportBar: View {
    @ObservedObject var controls: ShashatnaPlayerControls
    var body: some View {
        HStack(spacing: 24) {
            Button { controls.skip(-10) } label: { Image(systemName: "gobackward.10") }
                .accessibilityLabel("ترجيع عشر ثوانٍ")
            Button { controls.togglePlayback() } label: { Image(systemName: controls.isPlaying ? "pause.fill" : "play.fill") }
                .accessibilityLabel(controls.isPlaying ? "إيقاف مؤقت" : "تشغيل")
            Button { controls.skip(10) } label: { Image(systemName: "goforward.10") }
                .accessibilityLabel("تقديم عشر ثوانٍ")
            if controls.failureMessage == nil && (controls.waiting || controls.seeking) { ProgressView().tint(.white).accessibilityLabel("تحميل الفيديو") }
        }.font(.title2).buttonStyle(.plain).foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 50).background(.black)
            .environment(\.layoutDirection, .leftToRight)
    }
}

struct PlaybackFailureView: View {
    @ObservedObject var controls: ShashatnaPlayerControls
    var body: some View {
        if let message = controls.failureMessage {
            VStack(spacing: 8) {
                Text(message).font(.footnote).multilineTextAlignment(.center).foregroundStyle(.orange)
                HStack {
                    Button("إعادة المحاولة") { controls.retry() }
                    ShareLink(item: "Shashatna playback 0.9.9\n" + message) { Label("مشاركة الخطأ", systemImage: "square.and.arrow.up") }
                }.buttonStyle(.bordered)
            }.padding(12).frame(maxWidth: .infinity).background(.black)
        }
    }
}

struct ShashatnaCustomPlayer: View {
    @ObservedObject var controls: ShashatnaPlayerControls
    let title: String
    var fullscreen: () -> Void
    var attachEnabled = true
    var body: some View {
        ShashatnaNativePlayer(controls: controls, active: attachEnabled)
            .environment(\.layoutDirection, .leftToRight)
    }
}

struct ShashatnaFullscreenPlayer: View {
    @ObservedObject var controls: ShashatnaPlayerControls
    let title: String
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { dismiss() } label: { Label("رجوع", systemImage: "xmark") }.buttonStyle(.plain)
                Text(title).font(.caption).lineLimit(1)
                Spacer()
                Button { PlaybackOrientation.landscape() } label: { Label("بالعرض", systemImage: "rotate.right") }.buttonStyle(.plain)
            }.padding(.horizontal, 16).frame(minHeight: 44)
            ShashatnaNativePlayer(controls: controls)
                .environment(\.layoutDirection, .leftToRight)
            PlaybackTransportBar(controls: controls)
            PlaybackFailureView(controls: controls)
        }.foregroundStyle(.white).background(Color.black.ignoresSafeArea())
            .statusBarHidden(true)
            .task {
                // Wait for the full-screen hosting controller to enter its window scene.
                try? await Task.sleep(nanoseconds: 300_000_000)
                guard !Task.isCancelled else { return }
                PlaybackOrientation.landscape()
            }
    }
}

enum PlayerAudioSession {
    static func activate() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .moviePlayback)
        try session.setActive(true)
    }
}

struct PlaybackVariant: Identifiable {
    let id: String
    let label: String
    let resolution: Int
    let url: URL
    let container: String
}

struct PlaybackOptionsView: View {
    let sourceID: String
    let show: Show
    @EnvironmentObject private var downloads: DownloadManager
    @State private var variants: [PlaybackVariant] = []
    @State private var loading = false
    @State private var message: String?
    @State private var selectedID = ""
    private var selectedVariant: PlaybackVariant? { variants.first { $0.id == selectedID } ?? variants.first }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("المشاهدة").font(.title2.bold())
                Spacer()
                Image(systemName: "play.rectangle.on.rectangle").foregroundStyle(Theme.accent)
            }
            if loading { ProgressView("تجهيز خيارات المشاهدة…") }
            if let message = message { Text(message).font(.footnote).foregroundStyle(.orange) }
            if let variant = selectedVariant {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(variants) { option in
                            Button { selectedID = option.id } label: {
                                Text(option.label).font(.caption.bold()).padding(.horizontal, 17).padding(.vertical, 11)
                                    .background(option.id == variant.id ? Theme.accent : Color.white.opacity(0.07), in: Capsule())
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                }
                NavigationLink {
                    PlayerScreen(episode: Episode(id: "source-" + sourceID, title: show.title,
                                                  season: 1, number: 1, streamURL: variant.url), showID: show.id, show: show)
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "play.fill")
                        Text("شاهد الآن").font(.headline.bold())
                        Spacer()
                        Text(variant.label).font(.caption.bold()).padding(7).background(.white.opacity(0.15), in: Capsule())
                    }.foregroundStyle(.white).padding(18)
                        .background(LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 18))
                }.buttonStyle(.plain)
                if variant.container == "mp4" || variant.url.pathExtension.lowercased() == "mp4" {
                    Button {
                        downloads.enqueue(show: show, sourceID: sourceID, variant: variant)
                    } label: {
                        Label("تحميل الحلقة / العمل • " + variant.label, systemImage: "arrow.down.circle")
                            .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(12)
                    }.buttonStyle(.bordered)
                    NavigationLink("فتح التنزيلات") { DownloadsView() }.font(.caption)
                } else {
                    Text("هذه الجودة للبث فقط؛ التنزيل متاح لخيارات MP4.").font(.caption).foregroundStyle(.secondary)
                }
            }
            if !loading {
                Button(variants.isEmpty ? "إعادة المحاولة" : "تحديث خيارات المشاهدة") { Task { await loadVariants() } }
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.padding(18).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 22))
            .task(id: sourceID) { await loadVariants() }
    }

    @MainActor private func loadVariants() async {
        guard !loading, !sourceID.isEmpty, sourceID.utf8.allSatisfy({ (48...57).contains($0) }) else { return }
        loading = true
        message = nil
        variants = []
        defer { loading = false }
        do {
            guard let url = URL(string: "https://cinemana.shabakaty.com/api/android/transcoddedFiles/id/" + sourceID) else { throw PlaybackSourceError.invalid }
            let bytes = try await LibraryAPI.read(url)
            guard bytes.count <= 1_000_000 else { throw PlaybackSourceError.invalid }
            let parsed = try Self.parseVariants(bytes)
            try Task.checkCancellation()
            variants = parsed
            selectedID = parsed.first(where: { $0.resolution == 360 })?.id ?? parsed.first?.id ?? ""
        } catch is CancellationError {
            return
        } catch let error as PlaybackSourceError {
            switch error {
            case .http(let code):
                message = (code == 401 || code == 403) ? "الخدمة لم تسمح بالوصول إلى خيارات المشاهدة لهذا العمل." : "تعذّر تحميل خيارات المشاهدة. رمز الرد: \(code)."
            case .httpsRequired:
                message = "المصدر أعاد روابط غير آمنة أو غير مكتملة. يلزم رابط HTTPS كامل لتشغيلها هنا."
            case .empty:
                message = "لا توجد خيارات مشاهدة متاحة لهذا العمل في رد المصدر."
            case .invalid:
                message = "رد خيارات المشاهدة غير متوافق. استخدم فحص ملفات هذا العمل لمراجعة الرد."
            }
        } catch {
            if !Task.isCancelled { message = error.localizedDescription }
        }
    }

    static func parseVariants(_ data: Data) throws -> [PlaybackVariant] {
        guard let records = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw PlaybackSourceError.invalid }
        guard !records.isEmpty else { throw PlaybackSourceError.empty }
        var seen = Set<URL>()
        let variants = records.enumerated().compactMap { index, record -> PlaybackVariant? in
            guard let raw = record["videoUrl"] as? String,
                  let url = URL(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
                  url.scheme?.lowercased() == "https", url.host != nil,
                  url.user == nil, url.password == nil else { return nil }
            let container = (record["container"] as? String ?? "").lowercased()
            guard ["mp4", "hls", "m3u8"].contains(container) || ["mp4", "m3u8"].contains(url.pathExtension.lowercased()) else { return nil }
            guard seen.insert(url).inserted else { return nil }
            let resolutionText = record["resolution"] as? String ?? ""
            let name = record["name"] as? String ?? ""
            let resolution = Int(resolutionText.filter { $0.isNumber }) ?? 0
            let label = resolutionText.isEmpty ? (name.isEmpty ? "الجودة \(index + 1)" : name) : resolutionText
            return PlaybackVariant(id: String(index), label: label, resolution: resolution, url: url, container: container)
        }
        guard !variants.isEmpty else { throw PlaybackSourceError.httpsRequired }
        // Lower qualities first, so users can choose according to their connection.
        return variants.sorted { $0.resolution == $1.resolution ? $0.id < $1.id : $0.resolution < $1.resolution }
    }

    enum PlaybackSourceError: Error {
        case invalid, empty, httpsRequired, http(Int)
    }
}
