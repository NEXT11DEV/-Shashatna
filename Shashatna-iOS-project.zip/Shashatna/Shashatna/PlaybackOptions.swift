import SwiftUI
import Foundation
import AVKit
import UIKit

struct PlaybackVariant: Identifiable {
    let id: String
    let label: String
    let resolution: Int
    let url: URL
}

struct FullScreenPlaybackView: View {
    let player: AVPlayer
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()
            NativeFullScreenPlayer(player: player).ignoresSafeArea()
                .environment(\.layoutDirection, .leftToRight)
            Button { dismiss() } label: {
                Image(systemName: "xmark").font(.headline).foregroundStyle(.white).padding(14)
                    .background(.black.opacity(0.6), in: Circle())
            }.padding(20).accessibilityLabel("إغلاق الشاشة الكاملة")
        }.statusBarHidden(true).onAppear { player.play() }
    }
}

struct NativeFullScreenPlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = true
        controller.videoGravity = .resizeAspect
        return controller
    }
    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player { controller.player = player }
    }
}

struct PlaybackOptionsView: View {
    let sourceID: String
    let show: Show
    @State private var variants: [PlaybackVariant] = []
    @State private var loading = false
    @State private var message: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("اختر جودة المشاهدة").font(.title2.bold())
            if loading { ProgressView("تحميل خيارات المشاهدة…") }
            if let message = message { Text(message).font(.footnote).foregroundStyle(.orange) }
            ForEach(variants) { variant in
                NavigationLink {
                    PlayerScreen(episode: Episode(id: "source-" + sourceID, title: show.title,
                                                  season: 1, number: 1, streamURL: variant.url), showID: show.id)
                } label: {
                    HStack {
                        Image(systemName: "play.circle.fill").font(.title)
                        Text(variant.label).font(.headline)
                        Spacer()
                        Image(systemName: "chevron.left")
                    }.padding(16).background(Theme.accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 14))
                }
            }
            if !loading {
                Button(variants.isEmpty ? "إعادة المحاولة" : "تحديث روابط المشاهدة") { Task { await loadVariants() } }
                    .font(.footnote)
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
            .task(id: sourceID) { await loadVariants() }
    }

    @MainActor private func loadVariants() async {
        guard !loading, !sourceID.isEmpty, sourceID.utf8.allSatisfy({ (48...57).contains($0) }) else { return }
        loading = true
        message = nil
        variants = []
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.urlCredentialStorage = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel(); loading = false }
        do {
            guard let url = URL(string: "https://cinemana.shabakaty.com/api/android/transcoddedFiles/id/" + sourceID) else { throw PlaybackSourceError.invalid }
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (temporaryURL, response) = try await session.download(for: request)
            defer { try? FileManager.default.removeItem(at: temporaryURL) }
            try Task.checkCancellation()
            guard let http = response as? HTTPURLResponse else { throw PlaybackSourceError.invalid }
            guard (200...299).contains(http.statusCode) else { throw PlaybackSourceError.http(http.statusCode) }
            guard http.url?.host == url.host else { throw PlaybackSourceError.invalid }
            let attributes = try FileManager.default.attributesOfItem(atPath: temporaryURL.path)
            guard ((attributes[.size] as? NSNumber)?.intValue ?? 0) <= 1_000_000 else { throw PlaybackSourceError.invalid }
            let bytes = try Data(contentsOf: temporaryURL)
            let parsed = try Self.parseVariants(bytes)
            try Task.checkCancellation()
            variants = parsed
        } catch is CancellationError {
            return
        } catch let error as PlaybackSourceError {
            switch error {
            case .http(let code):
                message = (code == 401 || code == 403) ? "الخدمة لم تسمح بالوصول إلى خيارات المشاهدة لهذا العمل." : "تعذّر تحميل خيارات المشاهدة. رمز الرد: \(code)."
            case .httpsRequired:
                message = "المصدر أعاد روابط غير آمنة أو غير مكتملة. يلزم رابط HTTPS كامل لتشغيلها هنا."
            case .empty:
                message = "لا توجد خيارات مشاهدة متاحة لهذا العمل في رد المصدر."
            case .invalid:
                message = "رد خيارات المشاهدة غير متوافق. استخدم فحص ملفات هذا العمل لمراجعة الرد."
            }
        } catch {
            if !Task.isCancelled { message = "تعذّر الاتصال بمصدر المشاهدة من هذه الشبكة. جرّب إعادة المحاولة." }
        }
    }

    static func parseVariants(_ data: Data) throws -> [PlaybackVariant] {
        guard let records = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw PlaybackSourceError.invalid }
        guard !records.isEmpty else { throw PlaybackSourceError.empty }
        var seen = Set<URL>()
        let variants = records.enumerated().compactMap { index, record -> PlaybackVariant? in
            guard let raw = record["videoUrl"] as? String,
                  let url = URL(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
                  url.scheme?.lowercased() == "https", url.host != nil,
                  url.user == nil, url.password == nil else { return nil }
            let container = (record["container"] as? String ?? "").lowercased()
            guard ["mp4", "hls", "m3u8"].contains(container) || ["mp4", "m3u8"].contains(url.pathExtension.lowercased()) else { return nil }
            guard seen.insert(url).inserted else { return nil }
            let resolutionText = record["resolution"] as? String ?? ""
            let name = record["name"] as? String ?? ""
            let resolution = Int(resolutionText.filter { $0.isNumber }) ?? 0
            let label = resolutionText.isEmpty ? (name.isEmpty ? "الجودة \(index + 1)" : name) : resolutionText
            return PlaybackVariant(id: String(index), label: label, resolution: resolution, url: url)
        }
        guard !variants.isEmpty else { throw PlaybackSourceError.httpsRequired }
        // Lower qualities first, so users can choose according to their connection.
        return variants.sorted { $0.resolution == $1.resolution ? $0.id < $1.id : $0.resolution < $1.resolution }
    }

    enum PlaybackSourceError: Error {
        case invalid, empty, httpsRequired, http(Int)
    }
}
