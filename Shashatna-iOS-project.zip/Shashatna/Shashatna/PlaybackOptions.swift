import SwiftUI
import Foundation
import AVKit
import UIKit
import Combine

@MainActor final class ShashatnaPlayerControls: NSObject, ObservableObject, AVPictureInPictureControllerDelegate {
    let player: AVPlayer
    @Published var pipPossible = false
    @Published var pipActive = false
    @Published var pipMessage: String?
    private var pip: AVPictureInPictureController?
    private var observation: NSKeyValueObservation?
    private weak var attachedLayer: AVPlayerLayer?

    init(player: AVPlayer) { self.player = player; super.init() }
    func attach(_ layer: AVPlayerLayer) {
        guard attachedLayer !== layer, !pipActive else { return }
        attachedLayer = layer
        observation = nil
        pipPossible = false
        guard AVPictureInPictureController.isPictureInPictureSupported() else { return }
        pip = AVPictureInPictureController(playerLayer: layer)
        pip?.delegate = self
        pip?.canStartPictureInPictureAutomaticallyFromInline = true
        observation = pip?.observe(\.isPictureInPicturePossible, options: [.initial, .new]) { [weak self] controller, _ in
            let possible = controller.isPictureInPicturePossible
            Task { @MainActor [weak self] in self?.pipPossible = possible }
        }
    }
    func togglePiP() {
        guard let pip = pip else { return }
        pipMessage = nil
        if pip.isPictureInPictureActive { pip.stopPictureInPicture() }
        else if pip.isPictureInPicturePossible { pip.startPictureInPicture() }
    }
    nonisolated func pictureInPictureControllerDidStartPictureInPicture(_ controller: AVPictureInPictureController) {
        Task { @MainActor [weak self] in self?.pipActive = true }
    }
    nonisolated func pictureInPictureControllerDidStopPictureInPicture(_ controller: AVPictureInPictureController) {
        Task { @MainActor [weak self] in self?.pipActive = false }
    }
    nonisolated func pictureInPictureController(_ controller: AVPictureInPictureController, failedToStartPictureInPictureWithError error: Error) {
        Task { @MainActor [weak self] in
            self?.pipActive = false
            self?.pipMessage = "تعذّر فتح النافذة العائمة. تحقق من تفعيل صورة داخل صورة في إعدادات الآيفون."
        }
    }
    nonisolated func pictureInPictureController(_ controller: AVPictureInPictureController, restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        // The playback screen remains in the navigation stack while PiP is active.
        completionHandler(true)
    }
}

final class ShashatnaVideoSurface: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

struct ShashatnaPlayerSurface: UIViewRepresentable {
    @ObservedObject var controls: ShashatnaPlayerControls
    var attachEnabled = true
    func makeUIView(context: Context) -> ShashatnaVideoSurface {
        let view = ShashatnaVideoSurface()
        view.backgroundColor = .black
        view.playerLayer.player = controls.player
        view.playerLayer.videoGravity = .resizeAspect
        if attachEnabled { controls.attach(view.playerLayer) }
        return view
    }
    func updateUIView(_ view: ShashatnaVideoSurface, context: Context) {
        view.playerLayer.player = controls.player
        if attachEnabled { controls.attach(view.playerLayer) }
    }
}

struct ShashatnaCustomPlayer: View {
    @ObservedObject var controls: ShashatnaPlayerControls
    let title: String
    var fullscreen: () -> Void
    var attachEnabled = true
    @State private var seconds = 0.0
    @State private var duration = 0.0
    @State private var scrubbing = false
    @State private var isPlaying = false
    @State private var visible = true
    @State private var speed: Float = 1
    private let clock = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    var body: some View {
        ZStack {
            ShashatnaPlayerSurface(controls: controls, attachEnabled: attachEnabled)
                .contentShape(Rectangle()).onTapGesture { visible.toggle() }
            if visible {
                LinearGradient(colors: [.black.opacity(0.7), .clear, .black.opacity(0.85)], startPoint: .top, endPoint: .bottom)
                    .allowsHitTesting(false)
                VStack(spacing: 8) {
                    HStack {
                        Text(title).font(.caption).lineLimit(1).padding(.trailing, 90)
                        Spacer()
                    }
                    Spacer(minLength: 6)
                    HStack(spacing: 34) {
                        Button { seek(seconds - 10) } label: { Image(systemName: "gobackward.10").font(.title2) }.accessibilityLabel("ترجيع عشر ثوانٍ")
                        Button {
                            if controls.player.rate > 0 { controls.player.pause() }
                            else { controls.player.playImmediately(atRate: speed) }
                            isPlaying = controls.player.rate > 0
                        } label: {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill").font(.title)
                                .frame(width: 56, height: 56).background(Theme.accent.opacity(0.85), in: Circle())
                        }.accessibilityLabel(isPlaying ? "إيقاف مؤقت" : "تشغيل")
                        Button { seek(seconds + 10) } label: { Image(systemName: "goforward.10").font(.title2) }.accessibilityLabel("تقديم عشر ثوانٍ")
                    }
                    Spacer(minLength: 6)
                    HStack {
                        Text(time(seconds)).font(.system(.caption, design: .monospaced))
                        Slider(value: $seconds, in: 0...max(duration, 1), onEditingChanged: { editing in
                            scrubbing = editing
                            if !editing { seek(seconds) }
                        }).tint(Theme.accent).disabled(duration <= 0).accessibilityLabel("موضع المشاهدة")
                        Text(time(duration)).font(.system(.caption, design: .monospaced))
                    }
                    HStack {
                        Menu {
                            ForEach([Float(0.75), 1, 1.25, 1.5, 2], id: \.self) { rate in
                                Button(String(format: "%.2gx", rate)) {
                                    speed = rate
                                    if controls.player.rate > 0 { controls.player.rate = rate }
                                }
                            }
                        } label: { Text(String(format: "%.2gx", speed)).font(.caption.bold()) }
                        Spacer()
                        Button { controls.player.isMuted.toggle() } label: { Image(systemName: controls.player.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill") }.accessibilityLabel("تبديل كتم الصوت")
                        Button { controls.togglePiP() } label: { Image(systemName: "pip.enter") }
                            .disabled(!controls.pipPossible && !controls.pipActive).accessibilityLabel("نافذة عائمة")
                        Button(action: fullscreen) { Image(systemName: "arrow.up.left.and.arrow.down.right") }.accessibilityLabel("ملء الشاشة")
                    }
                }.padding(14)
            }
        }.overlay(alignment: .topTrailing) {
            Text("Shashatna").font(.system(size: 12, weight: .bold, design: .rounded))
                .foregroundStyle(LinearGradient(colors: [Color.cyan, Color.blue, Color.purple], startPoint: .leading, endPoint: .trailing))
                .shadow(color: .black.opacity(0.7), radius: 1, y: 1)
                .padding(.trailing, 12).padding(.top, 12)
                .allowsHitTesting(false).accessibilityHidden(true)
        }.foregroundStyle(.white).environment(\.layoutDirection, .leftToRight)
            .onReceive(clock) { _ in
                let length = controls.player.currentItem?.duration.seconds ?? 0
                duration = length.isFinite && length > 0 ? length : 0
                if !scrubbing {
                    let current = controls.player.currentTime().seconds
                    seconds = current.isFinite ? max(0, duration > 0 ? min(current, duration) : current) : 0
                }
                isPlaying = controls.player.rate > 0
            }
    }
    private func seek(_ target: Double) {
        guard duration > 0 else { return }
        seconds = min(max(target, 0), duration)
        controls.player.seek(to: CMTime(seconds: seconds, preferredTimescale: 600))
    }
    private func time(_ value: Double) -> String {
        let total = value.isFinite ? Int(max(value, 0)) : 0
        return total >= 3600 ? String(format: "%d:%02d:%02d", total / 3600, total / 60 % 60, total % 60) : String(format: "%d:%02d", total / 60, total % 60)
    }
}

struct ShashatnaFullscreenPlayer: View {
    @ObservedObject var controls: ShashatnaPlayerControls
    let title: String
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()
            ShashatnaCustomPlayer(controls: controls, title: title, fullscreen: { dismiss() }).ignoresSafeArea()
            Button { dismiss() } label: {
                Image(systemName: "xmark").foregroundStyle(.white).padding(12).background(.black.opacity(0.6), in: Circle())
            }.padding(12).accessibilityLabel("إغلاق الشاشة الكاملة")
        }.statusBarHidden(true)
    }
}

enum PlayerAudioSession {
    static func activate() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .moviePlayback)
        try session.setActive(true)
    }
}

struct PlaybackVariant: Identifiable {
    let id: String
    let label: String
    let resolution: Int
    let url: URL
    let container: String
}

struct FullScreenPlaybackView: View {
    let player: AVPlayer
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()
            NativeFullScreenPlayer(player: player).ignoresSafeArea()
                .environment(\.layoutDirection, .leftToRight)
            Button { dismiss() } label: {
                Image(systemName: "xmark").font(.headline).foregroundStyle(.white).padding(14)
                    .background(.black.opacity(0.6), in: Circle())
            }.padding(20).accessibilityLabel("إغلاق الشاشة الكاملة")
        }.statusBarHidden(true).onAppear { player.play() }
    }
}

struct NativeFullScreenPlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = true
        controller.allowsPictureInPicturePlayback = true
        controller.canStartPictureInPictureAutomaticallyFromInline = true
        controller.videoGravity = .resizeAspect
        return controller
    }
    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player { controller.player = player }
    }
}

struct PlaybackOptionsView: View {
    let sourceID: String
    let show: Show
    @EnvironmentObject private var downloads: DownloadManager
    @State private var variants: [PlaybackVariant] = []
    @State private var loading = false
    @State private var message: String?
    @State private var selectedID = ""
    private var selectedVariant: PlaybackVariant? { variants.first { $0.id == selectedID } ?? variants.first }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("المشاهدة").font(.title2.bold())
                Spacer()
                Image(systemName: "play.rectangle.on.rectangle").foregroundStyle(Theme.accent)
            }
            if loading { ProgressView("تجهيز خيارات المشاهدة…") }
            if let message = message { Text(message).font(.footnote).foregroundStyle(.orange) }
            if let variant = selectedVariant {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(variants) { option in
                            Button { selectedID = option.id } label: {
                                Text(option.label).font(.caption.bold()).padding(.horizontal, 17).padding(.vertical, 11)
                                    .background(option.id == variant.id ? Theme.accent : Color.white.opacity(0.07), in: Capsule())
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                }
                NavigationLink {
                    PlayerScreen(episode: Episode(id: "source-" + sourceID, title: show.title,
                                                  season: 1, number: 1, streamURL: variant.url), showID: show.id, show: show)
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "play.fill")
                        Text("شاهد الآن").font(.headline.bold())
                        Spacer()
                        Text(variant.label).font(.caption.bold()).padding(7).background(.white.opacity(0.15), in: Capsule())
                    }.foregroundStyle(.white).padding(18)
                        .background(LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 18))
                }.buttonStyle(.plain)
                if variant.container == "mp4" || variant.url.pathExtension.lowercased() == "mp4" {
                    Button {
                        downloads.enqueue(show: show, sourceID: sourceID, variant: variant)
                    } label: {
                        Label("تحميل الحلقة / العمل • " + variant.label, systemImage: "arrow.down.circle")
                            .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(12)
                    }.buttonStyle(.bordered)
                    NavigationLink("فتح التنزيلات") { DownloadsView() }.font(.caption)
                } else {
                    Text("هذه الجودة للبث فقط؛ التنزيل متاح لخيارات MP4.").font(.caption).foregroundStyle(.secondary)
                }
            }
            if !loading {
                Button(variants.isEmpty ? "إعادة المحاولة" : "تحديث خيارات المشاهدة") { Task { await loadVariants() } }
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.padding(18).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 22))
            .task(id: sourceID) { await loadVariants() }
    }

    @MainActor private func loadVariants() async {
        guard !loading, !sourceID.isEmpty, sourceID.utf8.allSatisfy({ (48...57).contains($0) }) else { return }
        loading = true
        message = nil
        variants = []
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.urlCredentialStorage = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel(); loading = false }
        do {
            guard let url = URL(string: "https://cinemana.shabakaty.com/api/android/transcoddedFiles/id/" + sourceID) else { throw PlaybackSourceError.invalid }
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (temporaryURL, response) = try await session.download(for: request)
            defer { try? FileManager.default.removeItem(at: temporaryURL) }
            try Task.checkCancellation()
            guard let http = response as? HTTPURLResponse else { throw PlaybackSourceError.invalid }
            guard (200...299).contains(http.statusCode) else { throw PlaybackSourceError.http(http.statusCode) }
            guard http.url?.host == url.host else { throw PlaybackSourceError.invalid }
            let attributes = try FileManager.default.attributesOfItem(atPath: temporaryURL.path)
            guard ((attributes[.size] as? NSNumber)?.intValue ?? 0) <= 1_000_000 else { throw PlaybackSourceError.invalid }
            let bytes = try Data(contentsOf: temporaryURL)
            let parsed = try Self.parseVariants(bytes)
            try Task.checkCancellation()
            variants = parsed
            selectedID = parsed.first(where: { $0.resolution == 360 })?.id ?? parsed.first?.id ?? ""
        } catch is CancellationError {
            return
        } catch let error as PlaybackSourceError {
            switch error {
            case .http(let code):
                message = (code == 401 || code == 403) ? "الخدمة لم تسمح بالوصول إلى خيارات المشاهدة لهذا العمل." : "تعذّر تحميل خيارات المشاهدة. رمز الرد: \(code)."
            case .httpsRequired:
                message = "المصدر أعاد روابط غير آمنة أو غير مكتملة. يلزم رابط HTTPS كامل لتشغيلها هنا."
            case .empty:
                message = "لا توجد خيارات مشاهدة متاحة لهذا العمل في رد المصدر."
            case .invalid:
                message = "رد خيارات المشاهدة غير متوافق. استخدم فحص ملفات هذا العمل لمراجعة الرد."
            }
        } catch {
            if !Task.isCancelled { message = "تعذّر الاتصال بمصدر المشاهدة من هذه الشبكة. جرّب إعادة المحاولة." }
        }
    }

    static func parseVariants(_ data: Data) throws -> [PlaybackVariant] {
        guard let records = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw PlaybackSourceError.invalid }
        guard !records.isEmpty else { throw PlaybackSourceError.empty }
        var seen = Set<URL>()
        let variants = records.enumerated().compactMap { index, record -> PlaybackVariant? in
            guard let raw = record["videoUrl"] as? String,
                  let url = URL(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
                  url.scheme?.lowercased() == "https", url.host != nil,
                  url.user == nil, url.password == nil else { return nil }
            let container = (record["container"] as? String ?? "").lowercased()
            guard ["mp4", "hls", "m3u8"].contains(container) || ["mp4", "m3u8"].contains(url.pathExtension.lowercased()) else { return nil }
            guard seen.insert(url).inserted else { return nil }
            let resolutionText = record["resolution"] as? String ?? ""
            let name = record["name"] as? String ?? ""
            let resolution = Int(resolutionText.filter { $0.isNumber }) ?? 0
            let label = resolutionText.isEmpty ? (name.isEmpty ? "الجودة \(index + 1)" : name) : resolutionText
            return PlaybackVariant(id: String(index), label: label, resolution: resolution, url: url, container: container)
        }
        guard !variants.isEmpty else { throw PlaybackSourceError.httpsRequired }
        // Lower qualities first, so users can choose according to their connection.
        return variants.sorted { $0.resolution == $1.resolution ? $0.id < $1.id : $0.resolution < $1.resolution }
    }

    enum PlaybackSourceError: Error {
        case invalid, empty, httpsRequired, http(Int)
    }
}
