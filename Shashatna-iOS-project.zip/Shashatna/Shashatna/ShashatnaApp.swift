import SwiftUI
import AVKit
import Combine

struct Episode: Codable, Identifiable {
    let id: String
    let title: String
    let season: Int
    let number: Int
    let streamURL: URL
}

struct Show: Codable, Identifiable {
    let id: String
    let title: String
    let category: String
    let synopsis: String
    let rating: Double
    let symbol: String
    let palette: Int
    let posterURL: URL?
    let episodes: [Episode]
}

enum Theme {
    static let background = Color(red: 0.045, green: 0.045, blue: 0.055)
    static let accent = Color(red: 0.70, green: 0.51, blue: 0.96)
    static func colors(_ index: Int) -> [Color] {
        let pairs: [[Color]] = [[.purple, .indigo], [.orange, .pink], [.teal, .blue], [.pink, .purple], [.blue, .indigo], [.green, .teal]]
        return pairs[abs(index % pairs.count)]
    }
}

@MainActor final class Catalog: ObservableObject {
    @Published var shows: [Show] = []
    @Published var favorites: Set<String>
    @Published var loading = false
    @Published var message: String?
    @Published var usingDemo = true
    private var loadGeneration = 0

    init() {
        favorites = Set(UserDefaults.standard.stringArray(forKey: "favorites") ?? [])
        if let url = Bundle.main.url(forResource: "catalog", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let items = try? JSONDecoder().decode([Show].self, from: data) { shows = items }
    }

    func toggle(_ show: Show) {
        if favorites.contains(show.id) { favorites.remove(show.id) } else { favorites.insert(show.id) }
        UserDefaults.standard.set(Array(favorites), forKey: "favorites")
    }

    func load(source: String) async {
        loadGeneration += 1
        let generation = loadGeneration
        let value = source.trimmingCharacters(in: .whitespacesAndNewlines)
        loading = true
        message = nil
        defer { if generation == loadGeneration { loading = false } }
        do {
            let data: Data
            let demo = value.isEmpty
            if demo {
                guard let local = Bundle.main.url(forResource: "catalog", withExtension: "json") else { throw CatalogError.invalid }
                data = try Data(contentsOf: local)
            } else {
                guard let url = URL(string: value), url.scheme?.lowercased() == "https", url.host != nil,
                      url.user == nil, url.password == nil else { throw CatalogError.https }
                var request = URLRequest(url: url)
                request.timeoutInterval = 20
                let (bytes, response) = try await URLSession.shared.data(for: request)
                guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw CatalogError.invalid }
                guard bytes.count <= 5_000_000 else { throw CatalogError.invalid }
                data = bytes
            }
            let decoded = try JSONDecoder().decode([Show].self, from: data)
            let allIDs = decoded.map(\.id)
            guard Set(allIDs).count == allIDs.count,
                  decoded.allSatisfy({ item in
                      Set(item.episodes.map(\.id)).count == item.episodes.count &&
                      item.episodes.allSatisfy { $0.streamURL.scheme?.lowercased() == "https" && $0.streamURL.host != nil } &&
                      (item.posterURL == nil || item.posterURL?.scheme?.lowercased() == "https")
                  }) else { throw CatalogError.invalid }
            guard generation == loadGeneration else { return }
            shows = decoded
            usingDemo = demo
        } catch {
            guard generation == loadGeneration else { return }
            message = (error as? CatalogError) == .https ? "رابط المصدر يجب أن يبدأ بـ HTTPS." : "تعذّر تحميل المصدر. تحقق من الرابط وبنية الملف واتصال الإنترنت."
        }
    }
    enum CatalogError: Error, Equatable { case https, invalid }
}

@main struct ShashatnaApp: App {
    @StateObject private var catalog = Catalog()
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(catalog)
                .environment(\.layoutDirection, .rightToLeft)
                .preferredColorScheme(.dark)
                .tint(Theme.accent)
        }
    }
}

struct RootView: View {
    @AppStorage("catalogSource") private var source = ""
    @EnvironmentObject private var catalog: Catalog
    var body: some View {
        TabView {
            NavigationStack { HomeView() }.tabItem { Label("الرئيسية", systemImage: "house") }
            NavigationStack { BrowseView(searchable: false, favoritesOnly: false) }.tabItem { Label("جميع الأعمال", systemImage: "play.rectangle") }
            NavigationStack { BrowseView(searchable: true, favoritesOnly: false) }.tabItem { Label("بحث", systemImage: "magnifyingglass") }
            NavigationStack { BrowseView(searchable: false, favoritesOnly: true) }.tabItem { Label("المكتبة", systemImage: "bookmark") }
        }.task { await catalog.load(source: source) }
    }
}

struct HomeView: View {
    @EnvironmentObject private var catalog: Catalog
    @State private var settings = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                VStack(alignment: .leading, spacing: 12) {
                    Label("ليلتك تبدأ هنا", systemImage: "sparkles").font(.title.bold())
                    Text("اكتشف حكاية جديدة، واحتفظ بما تحب.").foregroundStyle(.secondary)
                    if catalog.usingDemo { Text("مكتبة تجريبية • المشاهدة تعرض فيديو اختبار").font(.caption).foregroundStyle(Theme.accent) }
                }.frame(maxWidth: .infinity, alignment: .leading).padding(24)
                    .background(LinearGradient(colors: [.purple.opacity(0.3), .indigo.opacity(0.12)], startPoint: .topTrailing, endPoint: .bottomLeading), in: RoundedRectangle(cornerRadius: 26))
                if catalog.loading { ProgressView("تحميل المكتبة…") }
                if let message = catalog.message { Text(message).font(.footnote).foregroundStyle(.orange) }
                ForEach(Array(Set(catalog.shows.map(\.category))).sorted(), id: \.self) { category in
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text(category).font(.title2.bold())
                            Spacer()
                            NavigationLink("عرض الكل") { CategoryView(category: category) }.font(.subheadline)
                        }
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(alignment: .top, spacing: 14) {
                                ForEach(catalog.shows.filter { $0.category == category }) { show in
                                    NavigationLink { DetailView(show: show) } label: { PosterCard(show: show).frame(width: 155) }
                                }
                            }
                        }
                    }
                }
            }.padding(20)
        }.background(Theme.background).navigationTitle("شاشتنا")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button { settings = true } label: { Image(systemName: "gearshape") }.accessibilityLabel("الإعدادات") } }
            .sheet(isPresented: $settings) { SettingsView() }
    }
}

struct PosterArt: View {
    let show: Show
    var body: some View {
        ZStack {
            LinearGradient(colors: Theme.colors(show.palette), startPoint: .topLeading, endPoint: .bottomTrailing)
            if let url = show.posterURL {
                AsyncImage(url: url) { image in image.resizable().scaledToFill() } placeholder: { Image(systemName: show.symbol).font(.system(size: 55)).foregroundStyle(.white.opacity(0.8)) }
            } else {
                VStack(spacing: 28) {
                    Image(systemName: show.symbol).font(.system(size: 56, weight: .ultraLight))
                    Text(show.title).font(.title2.bold()).multilineTextAlignment(.center)
                }.foregroundStyle(.white).padding(16)
            }
        }.aspectRatio(2.0 / 3.0, contentMode: .fit).clipped().clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

struct PosterCard: View {
    let show: Show
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            PosterArt(show: show).overlay(alignment: .topTrailing) {
                Label(String(format: "%.1f", show.rating), systemImage: "star.fill")
                    .font(.caption.bold()).foregroundStyle(.yellow).padding(7)
                    .background(.black.opacity(0.65), in: Capsule()).padding(8)
            }
            Text(show.title).font(.headline).foregroundStyle(.white).lineLimit(1)
            Text(show.category).font(.caption).foregroundStyle(.secondary).lineLimit(1)
        }
    }
}

struct CategoryView: View {
    let category: String
    @EnvironmentObject private var catalog: Catalog
    var body: some View { ShowGrid(shows: catalog.shows.filter { $0.category == category }).navigationTitle(category) }
}

struct BrowseView: View {
    let searchable: Bool
    let favoritesOnly: Bool
    @State private var query = ""
    @EnvironmentObject private var catalog: Catalog
    var filtered: [Show] {
        catalog.shows.filter { show in
            (!favoritesOnly || catalog.favorites.contains(show.id)) &&
            (query.isEmpty || show.title.localizedStandardContains(query) || show.category.localizedStandardContains(query))
        }
    }
    var body: some View {
        Group {
            if searchable { ShowGrid(shows: filtered).searchable(text: $query, prompt: "ابحث عن فيلم أو مسلسل") }
            else { ShowGrid(shows: filtered) }
        }.navigationTitle(favoritesOnly ? "مكتبتي" : searchable ? "بحث" : "جميع الأعمال")
    }
}

struct ShowGrid: View {
    let shows: [Show]
    var body: some View {
        ScrollView {
            if shows.isEmpty {
                VStack(spacing: 14) {
                    Image(systemName: "film").font(.largeTitle)
                    Text("لا توجد أعمال هنا بعد").font(.headline)
                    Text("جرّب بحثًا آخر أو أضف أعمالًا إلى المكتبة.").font(.footnote).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity).padding(.top, 80)
            } else {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 24) {
                    ForEach(shows) { show in NavigationLink { DetailView(show: show) } label: { PosterCard(show: show) } }
                }.padding(20)
            }
        }.background(Theme.background)
    }
}

struct DetailView: View {
    let show: Show
    @EnvironmentObject private var catalog: Catalog
    @State private var season = 1
    var seasons: [Int] { Array(Set(show.episodes.map(\.season))).sorted() }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                PosterArt(show: show).frame(maxWidth: 230).frame(maxWidth: .infinity)
                HStack {
                    Text(show.title).font(.largeTitle.bold())
                    Spacer()
                    Button { catalog.toggle(show) } label: { Image(systemName: catalog.favorites.contains(show.id) ? "bookmark.fill" : "bookmark").font(.title2) }
                        .accessibilityLabel(catalog.favorites.contains(show.id) ? "إزالة من المكتبة" : "إضافة إلى المكتبة")
                }
                Text(show.category).foregroundStyle(Theme.accent)
                Text(show.synopsis).foregroundStyle(.secondary)
                if catalog.usingDemo { Text("هذه عناوين توضيحية؛ الحلقات تشغّل فيديو اختبار Apple.").font(.caption).foregroundStyle(.secondary) }
                if seasons.count > 1 {
                    Picker("الموسم", selection: $season) { ForEach(seasons, id: \.self) { Text("الموسم \($0)").tag($0) } }.pickerStyle(.segmented)
                }
                Text("الحلقات").font(.title2.bold())
                ForEach(show.episodes.filter { $0.season == season }.sorted { $0.number < $1.number }) { episode in
                    NavigationLink { PlayerScreen(episode: episode, showID: show.id) } label: {
                        HStack {
                            Image(systemName: "play.circle.fill").font(.title).foregroundStyle(Theme.accent)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(episode.title).foregroundStyle(.white)
                                Text("الحلقة \(episode.number)").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.left").foregroundStyle(.secondary)
                        }.padding().background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
                    }
                }
                if show.episodes.isEmpty { Text("لا توجد حلقات متاحة حاليًا.").foregroundStyle(.secondary) }
            }.padding(20)
        }.background(Theme.background).navigationBarTitleDisplayMode(.inline)
            .onAppear { season = seasons.first ?? 1 }
    }
}

struct PlayerScreen: View {
    let episode: Episode
    let showID: String
    @State private var player: AVPlayer
    @State private var failed = false
    @State private var completed = false
    init(episode: Episode, showID: String) {
        self.episode = episode
        self.showID = showID
        _player = State(initialValue: AVPlayer(url: episode.streamURL))
    }
    private var positionKey: String { "position.\(showID).\(episode.id)" }
    var body: some View {
        VStack(spacing: 18) {
            VideoPlayer(player: player).aspectRatio(16.0 / 9.0, contentMode: .fit)
                .environment(\.layoutDirection, .leftToRight)
            Text(episode.title).font(.title2.bold())
            Text("يمكنك التحكم بالمشاهدة من أزرار المشغّل.").font(.footnote).foregroundStyle(.secondary)
            if failed { Text("تعذّر تشغيل الفيديو. تحقق من الرابط والاتصال.").foregroundStyle(.orange) }
            Spacer()
        }.padding(.top).background(Theme.background).navigationTitle("المشاهدة").navigationBarTitleDisplayMode(.inline)
            .onAppear {
                let saved = UserDefaults.standard.double(forKey: positionKey)
                if saved.isFinite && saved > 0 { player.seek(to: CMTime(seconds: saved, preferredTimescale: 600)) }
                player.play()
            }
            .onDisappear {
                let seconds = player.currentTime().seconds
                if !completed && seconds.isFinite && seconds >= 0 { UserDefaults.standard.set(seconds, forKey: positionKey) }
                player.pause()
            }
            .onReceive(player.publisher(for: \.status).receive(on: RunLoop.main)) { failed = $0 == .failed }
            .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemFailedToPlayToEndTime)) { note in
                if let item = note.object as? AVPlayerItem, item === player.currentItem { failed = true }
            }
            .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemDidPlayToEndTime)) { note in
                if let item = note.object as? AVPlayerItem, item === player.currentItem {
                    completed = true
                    UserDefaults.standard.removeObject(forKey: positionKey)
                }
            }
    }
}

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var catalog: Catalog
    @AppStorage("catalogSource") private var source = ""
    @State private var draft = ""
    var body: some View {
        NavigationStack {
            Form {
                Section("مصدر المكتبة") {
                    TextField("https://…/catalog.json", text: $draft)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    Text("أدخل رابط مكتبتك بصيغة JSON. اتركه فارغًا لاستخدام المكتبة التجريبية.").font(.footnote)
                    Button("حفظ وتحميل") {
                        source = draft.trimmingCharacters(in: .whitespacesAndNewlines)
                        Task { await catalog.load(source: source) }
                    }.disabled(catalog.loading)
                    if catalog.loading { ProgressView() }
                    if let message = catalog.message { Text(message).foregroundStyle(.orange) }
                }
                Section("فحص اتصال شبكتي") {
                    NavigationLink("فحص المصدر من هذا الجهاز") { SourceDiagnosticsView() }
                    Text("يفحص الوصول وبيانات المكتبة من شبكة هاتفك، ثم يمكنك مشاركة التقرير لإكمال الربط.").font(.footnote)
                }
                Section("حول التطبيق") {
                    Text("شاشتنا • إصدار تجريبي 0.2")
                    Text("المفضلة ومكان المشاهدة محفوظان على جهازك. لا توجد حسابات أو اشتراكات في هذه النسخة.").font(.footnote)
                }
            }.navigationTitle("الإعدادات")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } } }
                .onAppear { draft = source }
        }
    }
}

struct SourceDiagnosticsView: View {
    @State private var running = false
    @State private var report = ""
    @State private var progress = ""
    private let endpoints = [
        "https://cinemana.shabakaty.com/api/android/categories",
        "https://cinemana.shabakaty.com/api/android/video/V/2"
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Label("اختبار الاتصال من هاتفك", systemImage: "network").font(.title2.bold())
                Text("نقرأ رد مسارين لبيانات المكتبة. النتيجة تبيّن إن كانت الخدمة متاحة وتعرض عيّنة من بنية الرد لتجهيز الربط.").foregroundStyle(.secondary)
                Button { Task { await runChecks() } } label: {
                    Label(running ? "الفحص جارٍ…" : "ابدأ فحص المصدر", systemImage: "antenna.radiowaves.left.and.right")
                        .frame(maxWidth: .infinity).padding(12)
                }.buttonStyle(.borderedProminent).disabled(running)
                if running { ProgressView(progress) }
                if !report.isEmpty {
                    ShareLink(item: report) { Label("مشاركة تقرير الفحص", systemImage: "square.and.arrow.up") }
                        .disabled(running)
                    Text("بعد اكتمال الفحص، أرسل التقرير هنا حتى نعرف بنية بيانات المصدر. ظهور JSON لا يعني أن صلاحية مشاهدة الفيديو متاحة.").font(.footnote).foregroundStyle(.secondary)
                    Text(report).font(.system(.caption, design: .monospaced))
                        .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
                        .environment(\.layoutDirection, .leftToRight)
                        .padding(14).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
                }
            }.padding(20)
        }.background(Theme.background).navigationTitle("فحص المصدر").navigationBarTitleDisplayMode(.inline)
    }

    @MainActor private func runChecks() async {
        running = true
        report = "Shashatna source diagnostics v0.2\nDate: \(ISO8601DateFormatter().string(from: Date()))\n"
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.urlCredentialStorage = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        let session = URLSession(configuration: configuration)
        defer {
            session.invalidateAndCancel()
            running = false
            progress = ""
        }
        for (index, address) in endpoints.enumerated() {
            progress = "فحص المسار \(index + 1) من \(endpoints.count)"
            report += "\nEndpoint: \(address)\n"
            guard let url = URL(string: address) else { continue }
            var request = URLRequest(url: url)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("Shashatna-Source-Diagnostics/0.2", forHTTPHeaderField: "User-Agent")
            do {
                // Download to a temporary file so a large response is not loaded into memory.
                let (temporaryURL, response) = try await session.download(for: request)
                defer { try? FileManager.default.removeItem(at: temporaryURL) }
                guard let http = response as? HTTPURLResponse else {
                    report += "Result: unexpected response type\n"
                    continue
                }
                report += "HTTP status: \(http.statusCode)\nContent-Type: \(http.mimeType ?? "unknown")\n"
                guard http.url?.host == url.host else {
                    report += "Result: redirected to a different host; content not included\n"
                    continue
                }
                guard (200...299).contains(http.statusCode) else {
                    report += "Result: access failed; response body not included\n"
                    continue
                }
                let attributes = try FileManager.default.attributesOfItem(atPath: temporaryURL.path)
                let size = (attributes[.size] as? NSNumber)?.intValue ?? 0
                report += "Response bytes: \(size)\n"
                guard size <= 1_000_000 else {
                    report += "Result: response too large for diagnostic sampling\n"
                    continue
                }
                let bytes = try Data(contentsOf: temporaryURL)
                guard let object = try? JSONSerialization.jsonObject(with: bytes) else {
                    report += "Result: not JSON; likely an HTML page or access message\n"
                    continue
                }
                if let dictionary = object as? [String: Any] {
                    report += "JSON root: object\nKeys: \(dictionary.keys.sorted().joined(separator: ", "))\n"
                } else if let array = object as? [Any] {
                    report += "JSON root: array\nItem count: \(array.count)\n"
                }
                let sample = sanitizedSample(object, depth: 0)
                if JSONSerialization.isValidJSONObject(sample),
                   let data = try? JSONSerialization.data(withJSONObject: sample, options: [.prettyPrinted, .sortedKeys]),
                   let text = String(data: data, encoding: .utf8) {
                    report += "Redacted schema sample (limited):\n\(text)\n"
                }
                report += "Result: JSON received; playback access not tested\n"
            } catch {
                // Only an error code is exported; URLs, cookies, and auth values are excluded.
                let errorCode = (error as NSError).code
                report += "Result: connection error (\(errorCode))\n"
            }
        }
    }

    private func sanitizedSample(_ value: Any, depth: Int) -> Any {
        guard depth < 5 else { return "[nested value omitted]" }
        if let dictionary = value as? [String: Any] {
            var sample: [String: Any] = [:]
            for key in dictionary.keys.sorted().prefix(30) {
                let lower = key.lowercased()
                let sensitive = ["token", "password", "secret", "authorization", "cookie", "email", "phone", "username", "session", "credential", "key", "url", "link", "file"].contains { lower.contains($0) }
                if sensitive { sample[key] = "[redacted]" }
                else if let child = dictionary[key] { sample[key] = sanitizedSample(child, depth: depth + 1) }
            }
            return sample
        }
        if let array = value as? [Any] { return array.prefix(2).map { sanitizedSample($0, depth: depth + 1) } }
        if let string = value as? String {
            if string.contains("://") || string.count > 160 { return "[string omitted]" }
            return string
        }
        if value is NSNumber || value is NSNull { return value }
        return "[value omitted]"
    }
}
