import SwiftUI
import AVKit
import Combine

struct Episode: Codable, Identifiable {
    let id: String
    let title: String
    let season: Int
    let number: Int
    let streamURL: URL
}

struct Show: Codable, Identifiable {
    let id: String
    let title: String
    let category: String
    let synopsis: String
    let rating: Double
    let symbol: String
    let palette: Int
    let posterURL: URL?
    let episodes: [Episode]
    let sourceID: String?
    let sourceKind: String?
    let sourceLanguageID: String?
    let sourceGenres: [String]?
    var alternateTitles: [String]? = nil
}

struct ResumeRecord: Codable, Identifiable {
    let show: Show
    let seconds: Double
    let duration: Double?
    let updated: Date
    var id: String { show.id }
}

enum Theme {
    static let background = Color(red: 0.025, green: 0.04, blue: 0.09)
    static let accent = Color(red: 0.38, green: 0.40, blue: 0.98)
    static func colors(_ index: Int) -> [Color] {
        let pairs: [[Color]] = [[.purple, .indigo], [.orange, .pink], [.teal, .blue], [.pink, .purple], [.blue, .indigo], [.green, .teal]]
        return pairs[abs(index % pairs.count)]
    }
}

@MainActor final class Catalog: ObservableObject {
    @Published var shows: [Show] = []
    @Published var favorites: Set<String>
    @Published var loading = false
    @Published var message: String?
    @Published var usingDemo = true
    @Published var resumeRecords: [ResumeRecord] = []
    @Published var savedFavorites: [Show] = []
    private var loadGeneration = 0

    init() {
        favorites = Set(UserDefaults.standard.stringArray(forKey: "favorites") ?? [])
        if let data = UserDefaults.standard.data(forKey: "resumeRecords"),
           let records = try? JSONDecoder().decode([ResumeRecord].self, from: data) { resumeRecords = records }
        if let data = UserDefaults.standard.data(forKey: "favoriteMetadata"),
           let records = try? JSONDecoder().decode([Show].self, from: data) { savedFavorites = records.filter { favorites.contains($0.id) } }
        if let url = Bundle.main.url(forResource: "catalog", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let items = try? JSONDecoder().decode([Show].self, from: data) { shows = items }
    }

    func toggle(_ show: Show) {
        if favorites.contains(show.id) {
            favorites.remove(show.id)
            savedFavorites.removeAll { $0.id == show.id }
        } else {
            favorites.insert(show.id)
            savedFavorites.removeAll { $0.id == show.id }
            savedFavorites.insert(show, at: 0)
        }
        UserDefaults.standard.set(Array(favorites), forKey: "favorites")
        if let data = try? JSONEncoder().encode(savedFavorites) { UserDefaults.standard.set(data, forKey: "favoriteMetadata") }
    }

    func recordWatch(show: Show, seconds: Double, duration: Double?) {
        guard seconds.isFinite, seconds >= 10 else { return }
        resumeRecords.removeAll { $0.id == show.id }
        let validDuration = duration.flatMap { $0.isFinite && $0 > 0 ? $0 : nil }
        resumeRecords.insert(ResumeRecord(show: show, seconds: seconds, duration: validDuration, updated: Date()), at: 0)
        resumeRecords = Array(resumeRecords.prefix(30))
        saveResumeRecords()
    }
    func removeResume(_ showID: String) {
        resumeRecords.removeAll { $0.id == showID }
        saveResumeRecords()
    }
    private func saveResumeRecords() {
        if let data = try? JSONEncoder().encode(resumeRecords) { UserDefaults.standard.set(data, forKey: "resumeRecords") }
    }

    func loadSourceOverview() async {
        let generation = loadGeneration
        loading = true
        defer { if generation == loadGeneration { loading = false } }
        for type in ["movie", "series"] {
            do {
                let url = URL(string: "https://cinemana.shabakaty.com/api/android/AdvancedSearch?videoTitle=&type=" + type + "&page=1")!
                let data = try await LibraryAPI.read(url)
                let incoming = try Self.decodeShabakaty(data)
                guard generation == loadGeneration else { return }
                var known = Set(shows.map(\.id))
                shows += incoming.filter { known.insert($0.id).inserted }
            } catch {
                guard generation == loadGeneration, !Task.isCancelled else { return }
                message = "تعذّر تحديث أحد أقسام الرئيسية. يمكنك إعادة المحاولة من تبويب الأفلام أو المسلسلات."
            }
        }
    }

    func load(source: String) async {
        loadGeneration += 1
        let generation = loadGeneration
        let value = source.trimmingCharacters(in: .whitespacesAndNewlines)
        loading = true
        message = nil
        defer { if generation == loadGeneration { loading = false } }
        do {
            let data: Data
            let demo = value.isEmpty
            if demo {
                guard let local = Bundle.main.url(forResource: "catalog", withExtension: "json") else { throw CatalogError.invalid }
                data = try Data(contentsOf: local)
            } else {
                let address = value == "shabakaty" ? "https://cinemana.shabakaty.com/api/android/video/V/2" : value
                guard let url = URL(string: address), url.scheme?.lowercased() == "https", url.host != nil,
                      url.user == nil, url.password == nil else { throw CatalogError.https }
                var request = URLRequest(url: url)
                request.timeoutInterval = 20
                request.setValue("application/json", forHTTPHeaderField: "Accept")
                let (bytes, response) = try await URLSession.shared.data(for: request)
                guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw CatalogError.invalid }
                guard bytes.count <= 5_000_000 else { throw CatalogError.invalid }
                data = bytes
            }
            let decoded: [Show]
            if value == "shabakaty" { decoded = try Self.decodeShabakaty(data) }
            else { decoded = try JSONDecoder().decode([Show].self, from: data) }
            let allIDs = decoded.map(\.id)
            guard Set(allIDs).count == allIDs.count,
                  decoded.allSatisfy({ item in
                      Set(item.episodes.map(\.id)).count == item.episodes.count &&
                      item.episodes.allSatisfy { $0.streamURL.scheme?.lowercased() == "https" && $0.streamURL.host != nil } &&
                      (item.posterURL == nil || item.posterURL?.scheme?.lowercased() == "https")
                  }) else { throw CatalogError.invalid }
            guard generation == loadGeneration else { return }
            shows = decoded
            usingDemo = demo
        } catch {
            guard generation == loadGeneration else { return }
            message = (error as? CatalogError) == .https ? "رابط المصدر يجب أن يبدأ بـ HTTPS." : "تعذّر تحميل المصدر من هذه الشبكة. تحقق من الاتصال أو جرّب إعادة التحميل من الإعدادات."
        }
    }

    static func decodeShabakaty(_ data: Data) throws -> [Show] {
        guard let records = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw CatalogError.invalid }
        var used = Set<String>()
        let items = records.enumerated().compactMap { index, record -> Show? in
            func text(_ key: String) -> String {
                if let value = record[key] as? String { return value.trimmingCharacters(in: .whitespacesAndNewlines) }
                if let number = record[key] as? NSNumber { return number.stringValue }
                return ""
            }
            let id = text("nb")
            guard !id.isEmpty, id.utf8.allSatisfy({ (48...57).contains($0) }), used.insert(id).inserted else { return nil }
            let title = text("ar_title").isEmpty ? text("en_title") : text("ar_title")
            guard !title.isEmpty else { return nil }
            let categories = record["categories"] as? [[String: Any]] ?? []
            let firstCategory = categories.first
            let category = (firstCategory?["ar_title"] as? String).flatMap { $0.isEmpty ? nil : $0 }
                ?? (firstCategory?["en_title"] as? String).flatMap { $0.isEmpty ? nil : $0 }
                ?? "أعمال من المصدر"
            let description = text("ar_content").isEmpty ? text("en_content") : text("ar_content")
            let poster = ["imgObjUrl", "imgMediumThumbObjUrl", "imgThumbObjUrl"].compactMap { key -> URL? in
                guard let raw = record[key] as? String, let url = URL(string: raw),
                      url.scheme?.lowercased() == "https", url.host != nil, url.user == nil, url.password == nil else { return nil }
                return url
            }.first
            return Show(id: "shabakaty-" + id, title: title, category: category, synopsis: description,
                        rating: Double(text("stars")) ?? Double(text("rate")) ?? 0, symbol: "film.fill", palette: index,
                        posterURL: poster, episodes: [], sourceID: id, sourceKind: text("kind"), sourceLanguageID: text("language_lighttigerNb"), sourceGenres: categories.flatMap { [$0["ar_title"] as? String, $0["en_title"] as? String].compactMap { $0 } }, alternateTitles: [text("ar_title"), text("en_title"), text("other_title")].filter { !$0.isEmpty })
        }
        guard !items.isEmpty || records.isEmpty else { throw CatalogError.invalid }
        return items
    }
    enum CatalogError: Error, Equatable { case https, invalid }
}

@main struct ShashatnaApp: App {
    @UIApplicationDelegateAdaptor(DownloadAppDelegate.self) private var appDelegate
    @StateObject private var catalog = Catalog()
    @StateObject private var downloads = DownloadManager.shared
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(catalog)
                .environmentObject(downloads)
                .environment(\.layoutDirection, .rightToLeft)
                .preferredColorScheme(.dark)
                .tint(Theme.accent)
        }
    }
}

struct RootView: View {
    @AppStorage("catalogSource") private var source = ""
    @EnvironmentObject private var catalog: Catalog
    var body: some View {
        TabView {
            NavigationStack { HomeView() }.tabItem { Label("الرئيسية", systemImage: "house") }
            NavigationStack { LibraryExplorerView(initialType: "all") }.tabItem { Label("بحث", systemImage: "magnifyingglass") }
            NavigationStack { LibraryExplorerView(initialType: "series") }.tabItem { Label("مسلسلات", systemImage: "tv") }
            NavigationStack { LibraryExplorerView(initialType: "animation") }.tabItem { Label("كرتون", systemImage: "sparkles.tv") }
            NavigationStack { SavedLibraryView() }.tabItem { Label("مكتبتي", systemImage: "bookmark") }
        }.task {
            if !UserDefaults.standard.bool(forKey: "liveCatalogMigrated03") {
                if source.isEmpty { source = "shabakaty" }
                UserDefaults.standard.set(true, forKey: "liveCatalogMigrated03")
            }
            await catalog.load(source: source)
            if source == "shabakaty" { await catalog.loadSourceOverview() }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var catalog: Catalog
    @State private var settings = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                HStack {
                    Image("ShashatnaBrand").resizable().scaledToFit().frame(width: 52, height: 52).clipShape(RoundedRectangle(cornerRadius: 12)).accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Shashatna").font(.system(size: 30, weight: .black))
                        Text("حكايات تستحق وقتك").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { settings = true } label: {
                        Label("الإعدادات", systemImage: "gearshape.fill").font(.caption.bold()).padding(12)
                            .background(.white.opacity(0.07), in: Capsule()).contentShape(Capsule())
                    }.buttonStyle(.plain).accessibilityLabel("الإعدادات")
                }.zIndex(2)
                if let featured = catalog.shows.first {
                    NavigationLink { DetailView(show: featured) } label: { FeaturedHero(show: featured).contentShape(RoundedRectangle(cornerRadius: 28)) }
                        .buttonStyle(.plain)
                }
                Button { settings = true } label: {
                    Label("الإعدادات وفحص المصادر", systemImage: "gearshape").frame(maxWidth: .infinity).padding(10)
                }.buttonStyle(.bordered).zIndex(2)
                HStack(spacing: 10) {
                    NavigationLink { LibraryExplorerView() } label: { Label("استكشف المكتبة", systemImage: "square.grid.2x2.fill") }
                        .buttonStyle(.borderedProminent)
                    Text(catalog.usingDemo ? "معاينة تجريبية" : "من المصدر مباشرة").font(.caption).foregroundStyle(.secondary)
                }
                NavigationLink { LibraryExplorerView(initialType: "all") } label: {
                    HStack {
                        Image(systemName: "magnifyingglass")
                        Text("ابحث في الأفلام والمسلسلات كلها").font(.subheadline)
                        Spacer()
                    }.foregroundStyle(.secondary).padding(18).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
                }.buttonStyle(.plain)
                if !catalog.resumeRecords.isEmpty {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("تابع المشاهدة").font(.title2.bold())
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(alignment: .top, spacing: 16) {
                                ForEach(catalog.resumeRecords) { record in
                                    NavigationLink { DetailView(show: record.show) } label: {
                                        VStack(alignment: .leading, spacing: 8) {
                                            PosterCard(show: record.show)
                                            if let duration = record.duration { ProgressView(value: min(record.seconds / duration, 1)).tint(Theme.accent) }
                                            Text("تابع من الدقيقة \(Int(record.seconds / 60))").font(.caption).foregroundStyle(.secondary)
                                        }.frame(width: 158)
                                    }.buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
                if catalog.loading { ProgressView("تحميل المكتبة…") }
                if let message = catalog.message { Text(message).font(.footnote).foregroundStyle(.orange) }
                ForEach(Array(Set(catalog.shows.map(\.category))).sorted(), id: \.self) { category in
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text(category).font(.title2.bold())
                            Spacer()
                            NavigationLink("عرض الكل") { CategoryView(category: category) }.font(.subheadline)
                        }
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(alignment: .top, spacing: 16) {
                                ForEach(catalog.shows.filter { $0.category == category }) { show in
                                    NavigationLink { DetailView(show: show) } label: { PosterCard(show: show).frame(width: 158) }
                                        .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
            }.padding(20)
        }.background(Theme.background).toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $settings) { SettingsView() }
    }
}

struct FeaturedHero: View {
    let show: Show
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottomLeading) {
                LinearGradient(colors: Theme.colors(show.palette), startPoint: .topLeading, endPoint: .bottomTrailing)
                if let url = show.posterURL {
                    AsyncImage(url: url) { image in image.resizable().scaledToFill() } placeholder: { Color.clear }
                        .frame(width: geometry.size.width, height: geometry.size.height).clipped().allowsHitTesting(false)
                }
                LinearGradient(colors: [.clear, .black.opacity(0.25), .black.opacity(0.95)], startPoint: .top, endPoint: .bottom)
                VStack(alignment: .leading, spacing: 12) {
                    Text("اختيار من المكتبة").font(.caption.bold()).padding(.horizontal, 12).padding(.vertical, 6)
                        .background(Theme.accent.opacity(0.9), in: Capsule())
                    Text(show.title).font(.system(size: 29, weight: .heavy)).lineLimit(2)
                    Text(show.synopsis).font(.footnote).foregroundStyle(.white.opacity(0.75)).lineLimit(2)
                    HStack {
                        Label("التفاصيل والمشاهدة", systemImage: "play.fill").font(.subheadline.bold())
                            .padding(.horizontal, 18).padding(.vertical, 12).background(.white, in: Capsule()).foregroundStyle(.black)
                        Spacer()
                        Text(show.category).font(.caption).foregroundStyle(.white.opacity(0.8))
                    }
                }.padding(22)
            }.frame(width: geometry.size.width, height: geometry.size.height)
                .clipped().clipShape(RoundedRectangle(cornerRadius: 28))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(.white.opacity(0.08), lineWidth: 1))
        }.frame(height: 390).contentShape(RoundedRectangle(cornerRadius: 28)).foregroundStyle(.white)
    }
}

struct PosterArt: View {
    let show: Show
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(colors: Theme.colors(show.palette), startPoint: .topLeading, endPoint: .bottomTrailing)
                if let url = show.posterURL {
                    AsyncImage(url: url) { phase in
                        if let image = phase.image { image.resizable().scaledToFill() }
                        else { Image(systemName: show.symbol).font(.system(size: 44)).foregroundStyle(.white.opacity(0.7)) }
                    }.frame(width: geometry.size.width, height: geometry.size.height).clipped().allowsHitTesting(false)
                } else {
                    VStack(spacing: 24) {
                        Image(systemName: show.symbol).font(.system(size: 52, weight: .ultraLight))
                        Text(show.title).font(.title2.bold()).multilineTextAlignment(.center)
                    }.foregroundStyle(.white).padding(16)
                }
            }.frame(width: geometry.size.width, height: geometry.size.height).clipped().allowsHitTesting(false)
                .clipShape(RoundedRectangle(cornerRadius: 18))
        }.aspectRatio(2.0 / 3.0, contentMode: .fit)
    }
}

struct PosterCard: View {
    let show: Show
    var body: some View {
        PosterArt(show: show)
            .overlay(alignment: .bottomLeading) {
                VStack(alignment: .leading, spacing: 5) {
                    Spacer(minLength: 20)
                    Text(show.title).font(.subheadline.bold()).foregroundStyle(.white).lineLimit(2)
                    Text(show.category).font(.system(size: 10)).foregroundStyle(.white.opacity(0.65)).lineLimit(1)
                }.padding(13).frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [.clear, .black.opacity(0.95)], startPoint: .center, endPoint: .bottom))
            }
            .overlay(alignment: .topTrailing) {
                if show.rating > 0 {
                    Label(String(format: "%.1f", show.rating), systemImage: "star.fill")
                        .font(.caption.bold()).foregroundStyle(.yellow).padding(7)
                        .background(.black.opacity(0.65), in: Capsule()).padding(8)
                }
            }.clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.08), lineWidth: 1))
    }
}

struct CategoryView: View {
    let category: String
    @EnvironmentObject private var catalog: Catalog
    var body: some View { ShowGrid(shows: catalog.shows.filter { $0.category == category }).navigationTitle(category) }
}

struct BrowseView: View {
    let searchable: Bool
    let favoritesOnly: Bool
    @State private var query = ""
    @EnvironmentObject private var catalog: Catalog
    var filtered: [Show] {
        var known = Set<String>()
        let available = favoritesOnly ? (catalog.savedFavorites + catalog.shows).filter { known.insert($0.id).inserted } : catalog.shows
        return available.filter { show in
            (!favoritesOnly || catalog.favorites.contains(show.id)) &&
            (query.isEmpty || show.title.localizedStandardContains(query) || show.category.localizedStandardContains(query))
        }
    }
    var body: some View {
        Group {
            if searchable { ShowGrid(shows: filtered).searchable(text: $query, prompt: "ابحث عن فيلم أو مسلسل") }
            else { ShowGrid(shows: filtered) }
        }.navigationTitle(favoritesOnly ? "مكتبتي" : searchable ? "بحث" : "جميع الأعمال")
    }
}

struct ShowGrid: View {
    let shows: [Show]
    var body: some View {
        ScrollView {
            if shows.isEmpty {
                VStack(spacing: 14) {
                    Image(systemName: "film").font(.largeTitle)
                    Text("لا توجد أعمال هنا بعد").font(.headline)
                    Text("جرّب بحثًا آخر أو أضف أعمالًا إلى المكتبة.").font(.footnote).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity).padding(.top, 80)
            } else {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 24) {
                    ForEach(shows) { show in NavigationLink { DetailView(show: show) } label: { PosterCard(show: show) } }
                }.padding(20)
            }
        }.background(Theme.background)
    }
}

struct DetailView: View {
    let show: Show
    @EnvironmentObject private var catalog: Catalog
    @State private var season = 1
    @State private var expanded = false
    @State private var details: Show?
    private var content: Show { details ?? show }
    private var seasons: [Int] { Array(Set(show.episodes.map(\.season))).sorted() }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                DetailHero(show: content)
                HStack(spacing: 12) {
                    Label(content.sourceKind == "1" ? "فيلم" : "مسلسل / عمل", systemImage: content.sourceKind == "1" ? "film" : "tv")
                    Text(content.category)
                    Spacer()
                    Button { catalog.toggle(show) } label: {
                        Image(systemName: catalog.favorites.contains(show.id) ? "bookmark.fill" : "bookmark")
                            .padding(12).background(Theme.accent.opacity(0.15), in: Circle())
                    }.accessibilityLabel("حفظ في المكتبة")
                }.font(.caption.bold()).foregroundStyle(Theme.accent)
                if !content.synopsis.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("القصة").font(.title3.bold())
                        Text(content.synopsis).font(.subheadline).foregroundStyle(.secondary).lineSpacing(5).lineLimit(expanded ? nil : 4)
                        Button(expanded ? "عرض أقل" : "قراءة المزيد") { expanded.toggle() }.font(.caption.bold())
                    }.padding(18).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 22))
                }
                if let sourceID = content.sourceID {
                    if content.sourceKind == "1" { PlaybackOptionsView(sourceID: sourceID, show: content) }
                    else { RemoteSeriesEpisodesView(sourceID: sourceID, show: content) }
                    NavigationLink { SourceDiagnosticsView(selectedID: sourceID) } label: {
                        Label("فحص اتصال هذا العمل", systemImage: "waveform.path.ecg")
                    }.font(.caption)
                } else {
                    if seasons.count > 1 {
                        Picker("الموسم", selection: $season) { ForEach(seasons, id: \.self) { Text("الموسم \($0)").tag($0) } }.pickerStyle(.segmented)
                    }
                    ForEach(show.episodes.filter { $0.season == season }.sorted { $0.number < $1.number }) { episode in
                        NavigationLink { PlayerScreen(episode: episode, showID: show.id, show: show) } label: {
                            Label(episode.title, systemImage: "play.circle.fill").padding(18)
                        }.buttonStyle(.bordered)
                    }
                }
            }.padding(20)
        }.background(Theme.background).navigationBarTitleDisplayMode(.inline)
            .task(id: show.sourceID) {
                season = seasons.first ?? 1
                guard let id = show.sourceID, id.utf8.allSatisfy({ (48...57).contains($0) }), !id.isEmpty else { return }
                do {
                    let bytes = try await LibraryAPI.read(URL(string: "https://cinemana.shabakaty.com/api/android/allVideoInfo/id/" + id)!)
                    guard let object = try JSONSerialization.jsonObject(with: bytes) as? [String: Any] else { return }
                    let data = try JSONSerialization.data(withJSONObject: [object])
                    if let fresh = try Catalog.decodeShabakaty(data).first {
                        details = Show(id: show.id, title: fresh.title, category: fresh.category,
                                       synopsis: fresh.synopsis, rating: fresh.rating, symbol: fresh.symbol,
                                       palette: fresh.palette, posterURL: fresh.posterURL, episodes: fresh.episodes,
                                       sourceID: fresh.sourceID, sourceKind: fresh.sourceKind,
                                       sourceLanguageID: fresh.sourceLanguageID, sourceGenres: fresh.sourceGenres)
                    }
                } catch { }
            }
    }
}

struct DetailHero: View {
    let show: Show
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            LinearGradient(colors: [.blue.opacity(0.45), .purple.opacity(0.4), Theme.background], startPoint: .topTrailing, endPoint: .bottomLeading)
            if let url = show.posterURL {
                AsyncImage(url: url) { image in image.resizable().scaledToFill().blur(radius: 24) } placeholder: { Color.clear }
                    .frame(height: 310).clipped().opacity(0.3)
            }
            HStack(alignment: .bottom, spacing: 18) {
                PosterArt(show: show).frame(width: 126)
                    .shadow(color: .black.opacity(0.6), radius: 16, y: 10)
                VStack(alignment: .leading, spacing: 12) {
                    Text("Shashatna • تفاصيل العمل").font(.system(size: 9, weight: .bold)).tracking(1.5).foregroundStyle(Theme.accent)
                    Text(show.title).font(.system(size: 26, weight: .heavy)).lineLimit(3)
                    if show.rating > 0 { Label(String(format: "%.1f", show.rating), systemImage: "star.fill").font(.caption.bold()).foregroundStyle(.yellow) }
                    Text(show.category).font(.caption).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity, alignment: .leading)
            }.padding(20)
        }.frame(height: 310).clipped().clipShape(RoundedRectangle(cornerRadius: 26))
    }
}

struct PlayerScreen: View {
    let episode: Episode
    let showID: String
    let show: Show?
    @EnvironmentObject private var catalog: Catalog
    @State private var player: AVPlayer
    @StateObject private var controls: ShashatnaPlayerControls
    @State private var failed = false
    @State private var completed = false
    @State private var fullScreen = false
    @State private var started = false
    @State private var audioProblem: String?
    init(episode: Episode, showID: String, show: Show? = nil) {
        self.episode = episode
        self.showID = showID
        self.show = show
        let playbackPlayer = AVPlayer(url: episode.streamURL)
        _player = State(initialValue: playbackPlayer)
        _controls = StateObject(wrappedValue: ShashatnaPlayerControls(player: playbackPlayer))
    }
    private var positionKey: String { "position.\(showID).\(episode.id)" }
    private var itemStatusPublisher: AnyPublisher<AVPlayerItem.Status, Never> {
        if let item = player.currentItem {
            return item.publisher(for: \.status).receive(on: RunLoop.main).eraseToAnyPublisher()
        }
        return Just(AVPlayerItem.Status.unknown).eraseToAnyPublisher()
    }
    var body: some View {
        VStack(spacing: 18) {
            ShashatnaCustomPlayer(controls: controls, title: episode.title, fullscreen: { fullScreen = true }, attachEnabled: !fullScreen).aspectRatio(16.0 / 9.0, contentMode: .fit)
                .environment(\.layoutDirection, .leftToRight)
            Button { fullScreen = true } label: {
                Label("ملء الشاشة", systemImage: "arrow.up.left.and.arrow.down.right")
                    .font(.headline).frame(maxWidth: .infinity).padding(14)
            }.buttonStyle(.borderedProminent).padding(.horizontal, 20)
            Text(episode.title).font(.title2.bold())
            Text("اضغط رمز النافذة العائمة داخل المشغّل، أو اخرج للشاشة الرئيسية أثناء تشغيل الفيديو.").font(.footnote).foregroundStyle(.secondary)
            if failed { Text("تعذّر تشغيل الفيديو. تحقق من الرابط والاتصال.").foregroundStyle(.orange) }
            if let audioProblem = audioProblem { Text(audioProblem).font(.footnote).foregroundStyle(.orange) }
            if let message = controls.pipMessage { Text(message).font(.footnote).foregroundStyle(.secondary) }
            Spacer()
        }.padding(.top).background(Theme.background).navigationTitle("المشاهدة").navigationBarTitleDisplayMode(.inline)
            .onAppear {
                do {
                    try PlayerAudioSession.activate()
                    audioProblem = nil
                } catch {
                    audioProblem = "تعذّر تفعيل صوت المشاهدة. جرّب إعادة فتح المشغّل."
                }
                if !started {
                    player.isMuted = false
                    player.volume = 1
                    let saved = UserDefaults.standard.double(forKey: positionKey)
                    if saved.isFinite && saved > 0 { player.seek(to: CMTime(seconds: saved, preferredTimescale: 600)) }
                    started = true
                }
                player.play()
            }
            .fullScreenCover(isPresented: $fullScreen, onDismiss: { player.play() }) {
                ShashatnaFullscreenPlayer(controls: controls, title: episode.title)
            }
            .onDisappear {
                guard !fullScreen, !controls.pipActive else { return }
                let seconds = player.currentTime().seconds
                if !completed && seconds.isFinite && seconds >= 0 { UserDefaults.standard.set(seconds, forKey: positionKey) }
                if !completed, let show = show { catalog.recordWatch(show: show, seconds: seconds, duration: player.currentItem?.duration.seconds) }
                player.pause()
            }
            .onReceive(player.publisher(for: \.status).receive(on: RunLoop.main)) { failed = $0 == .failed }
            .onReceive(itemStatusPublisher) { if $0 == .failed { failed = true } }
            .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemFailedToPlayToEndTime)) { note in
                if let item = note.object as? AVPlayerItem, item === player.currentItem { failed = true }
            }
            .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemDidPlayToEndTime)) { note in
                if let item = note.object as? AVPlayerItem, item === player.currentItem {
                    completed = true
                    UserDefaults.standard.removeObject(forKey: positionKey)
                    catalog.removeResume(showID)
                }
            }
    }
}

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var catalog: Catalog
    @AppStorage("catalogSource") private var source = ""
    @State private var draft = ""
    var body: some View {
        NavigationStack {
            Form {
                Section("مصدر المكتبة") {
                    Button("تحميل قائمة شبكتي") {
                        source = "shabakaty"
                        draft = ""
                        Task { await catalog.load(source: source) }
                    }.disabled(catalog.loading)
                    Text(source == "shabakaty" ? "المصدر الحالي: شبكتي — قائمة الأعمال المتاحة" : "المصدر الحالي: مكتبة JSON")
                        .font(.caption).foregroundStyle(.secondary)
                    TextField("https://…/catalog.json", text: $draft)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    Text("أدخل رابط مكتبتك بصيغة JSON. اتركه فارغًا لاستخدام المكتبة التجريبية.").font(.footnote)
                    Button("حفظ وتحميل") {
                        source = draft.trimmingCharacters(in: .whitespacesAndNewlines)
                        Task { await catalog.load(source: source) }
                    }.disabled(catalog.loading)
                    if catalog.loading { ProgressView() }
                    if let message = catalog.message { Text(message).foregroundStyle(.orange) }
                }
                Section("فحص اتصال شبكتي") {
                    NavigationLink("فحص المصدر من هذا الجهاز") { SourceDiagnosticsView() }
                    NavigationLink("فحص مكتبات MOX") { SourceDiagnosticsView(provider: "mox") }
                    Text("يفحص الوصول وبيانات المكتبة من شبكة هاتفك، ثم يمكنك مشاركة التقرير لإكمال الربط.").font(.footnote)
                }
                Section("حول التطبيق") {
                    Image("ShashatnaBrand").resizable().scaledToFit().frame(width: 80, height: 80)
                    Text("Shashatna • إصدار تجريبي 0.9.1")
                    Text("© 2026 Shashatna").font(.caption).foregroundStyle(.secondary)
                    NavigationLink("التنزيلات والمشاهدة دون إنترنت") { DownloadsView() }
                    Text("المفضلة ومكان المشاهدة والتنزيلات محفوظة على جهازك. لا توجد حسابات أو اشتراكات في هذه النسخة.").font(.footnote)
                }
            }.navigationTitle("الإعدادات")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } } }
                .onAppear { draft = source == "shabakaty" ? "" : source }
        }
    }
}

enum SourcePayloadCodec {
    struct Inspection {
        let object: Any?
        let format: String
        let detail: String
    }
    static func inspect(_ input: Data) -> Inspection {
        guard input.count <= 1_000_000 else {
            return Inspection(object: nil, format: "oversized", detail: "Payload omitted")
        }
        var current = input
        for depth in 0...2 {
            let parsed = try? JSONSerialization.jsonObject(with: current, options: [.fragmentsAllowed])
            if let object = parsed, object is [String: Any] || object is [Any] {
                return Inspection(object: object, format: depth == 0 ? "JSON" : "Base64-wrapped JSON", detail: "Base64 layers: \(depth); decoded bytes: \(current.count)")
            }
            guard let text = (parsed as? String) ?? String(data: current, encoding: .utf8) else {
                return Inspection(object: nil, format: "binary payload", detail: "Base64 layers: \(depth); decoded bytes: \(current.count); UTF-8: false; format unknown")
            }
            guard depth < 2 else { break }
            var compact = text.components(separatedBy: .whitespacesAndNewlines).joined()
            let valid = compact.count >= 8 && compact.utf8.allSatisfy {
                (65...90).contains($0) || (97...122).contains($0) || (48...57).contains($0) || [43, 47, 61, 45, 95].contains($0)
            }
            guard valid, compact.count % 4 != 1 else {
                return Inspection(object: nil, format: "non-JSON text", detail: "Base64 layers: \(depth); text characters: \(text.count); body omitted")
            }
            compact = compact.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
            compact += String(repeating: "=", count: (4 - compact.count % 4) % 4)
            guard let decoded = Data(base64Encoded: compact) else {
                return Inspection(object: nil, format: "invalid Base64", detail: "Body omitted")
            }
            current = decoded
        }
        return Inspection(object: nil, format: "non-JSON payload", detail: "At most two Base64 layers inspected; no secret values exported")
    }
}

struct SourceDiagnosticsView: View {
    var selectedID: String? = nil
    var searchQuery: String? = nil
    var provider = "shabakaty"
    @State private var running = false
    @State private var report = ""
    @State private var progress = ""
    private var endpoints: [String] {
        if provider == "mox" {
            return ["/vlab/class/list", "/vlab/market/banner/list", "/vlab/show/popular/list", "/vlab/show/recommend/list", "/vlab/show/search"].map { "https://mca.mooxapp.click" + $0 }
        }
        var addresses = [
            "https://cinemana.shabakaty.com/api/android/categories",
            "https://cinemana.shabakaty.com/api/android/video/V/2",
            "https://cinemana.shabakaty.com/api/android/AdvancedSearch?videoTitle=&type=movie&page=1",
            "https://cinemana.shabakaty.com/api/android/AdvancedSearch?videoTitle=&type=movie&page=2",
            "https://cinemana.shabakaty.com/api/android/AdvancedSearch?videoTitle=&type=series&page=1"
        ]
        if let id = selectedID, !id.isEmpty, id.utf8.allSatisfy({ (48...57).contains($0) }) {
            addresses += [
                "https://cinemana.shabakaty.com/api/android/allVideoInfo/id/" + id,
                "https://cinemana.shabakaty.com/api/android/transcoddedFiles/id/" + id,
                "https://cinemana.shabakaty.com/api/android/videoSeason/id/" + id
            ]
        }
        let savedQuery = UserDefaults.standard.string(forKey: "lastSearchQuery") ?? ""
        let testedQuery = LibraryBrowseModel.cleanQuery(searchQuery ?? savedQuery)
        let testQueries = Array(Set(["One Crazy Summer", "ليل وقضبان"] + (testedQuery.isEmpty ? ["Yeraltı", "Yeralti"] : TitleSearch.variants(testedQuery)))).sorted()
        for query in testQueries {
            for type in ["movie", "series"] {
                var parts = URLComponents(string: "https://cinemana.shabakaty.com/api/android/AdvancedSearch")!
                parts.queryItems = [URLQueryItem(name: "videoTitle", value: query), URLQueryItem(name: "type", value: type), URLQueryItem(name: "page", value: "1")]
                if let url = parts.url { addresses.append(url.absoluteString) }
            }
        }
        return addresses
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Label("اختبار الاتصال من هاتفك", systemImage: "network").font(.title2.bold())
                Text(provider == "mox" ? "فحص قراءة مسارات MOX المعروفة من شبكة هاتفك. هذه خطوة تشخيص، ولا تعني أن مكتباته مضافة بعد." : selectedID == nil ? "نفحص بيانات المكتبة وأول صفحتين من التصفح." : "نفحص التصفح وتفاصيل هذا العمل وملفات المشاهدة والحلقات.").foregroundStyle(.secondary)
                Button { Task { await runChecks() } } label: {
                    Label(running ? "الفحص جارٍ…" : "ابدأ فحص المصدر", systemImage: "antenna.radiowaves.left.and.right")
                        .frame(maxWidth: .infinity).padding(12)
                }.buttonStyle(.borderedProminent).disabled(running)
                if running { ProgressView(progress) }
                if !report.isEmpty {
                    ShareLink(item: report) { Label("مشاركة تقرير الفحص", systemImage: "square.and.arrow.up") }
                        .disabled(running)
                    Text("بعد اكتمال الفحص، أرسل التقرير هنا حتى نعرف بنية بيانات المصدر. ظهور JSON لا يعني أن صلاحية مشاهدة الفيديو متاحة.").font(.footnote).foregroundStyle(.secondary)
                    Text(report).font(.system(.caption, design: .monospaced))
                        .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
                        .environment(\.layoutDirection, .leftToRight)
                        .padding(14).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
                }
            }.padding(20)
        }.background(Theme.background).navigationTitle("فحص المصدر").navigationBarTitleDisplayMode(.inline)
    }

    @MainActor private func runChecks() async {
        running = true
        report = "Shashatna source diagnostics v0.9.1\nProvider: \(provider)\nDate: \(ISO8601DateFormatter().string(from: Date()))\n"
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.urlCredentialStorage = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        let session = URLSession(configuration: configuration)
        defer {
            session.invalidateAndCancel()
            running = false
            progress = ""
        }
        for (index, address) in endpoints.enumerated() {
            progress = "فحص المسار \(index + 1) من \(endpoints.count)"
            report += "\nEndpoint: \(address)\n"
            guard let url = URL(string: address) else { continue }
            var request = URLRequest(url: url)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("Shashatna-Source-Diagnostics/0.3", forHTTPHeaderField: "User-Agent")
            do {
                // Download to a temporary file so a large response is not loaded into memory.
                let (temporaryURL, response) = try await session.download(for: request)
                defer { try? FileManager.default.removeItem(at: temporaryURL) }
                guard let http = response as? HTTPURLResponse else {
                    report += "Result: unexpected response type\n"
                    continue
                }
                report += "HTTP status: \(http.statusCode)\nContent-Type: \(http.mimeType ?? "unknown")\n"
                guard http.url?.host == url.host else {
                    report += "Result: redirected to a different host; content not included\n"
                    continue
                }
                guard (200...299).contains(http.statusCode) else {
                    report += "Result: access failed; response body not included\n"
                    continue
                }
                let attributes = try FileManager.default.attributesOfItem(atPath: temporaryURL.path)
                let size = (attributes[.size] as? NSNumber)?.intValue ?? 0
                report += "Response bytes: \(size)\n"
                guard size <= 1_000_000 else {
                    report += "Result: response too large for diagnostic sampling\n"
                    continue
                }
                let bytes = try Data(contentsOf: temporaryURL)
                let inspection = SourcePayloadCodec.inspect(bytes)
                report += "Payload format: \(inspection.format)\n\(inspection.detail)\n"
                guard let object = inspection.object else {
                    report += "Result: usable JSON was not received; library access not established\n"
                    continue
                }
                if let dictionary = object as? [String: Any] {
                    report += "JSON root: object\nKeys: \(dictionary.keys.sorted().joined(separator: ", "))\n"
                } else if let array = object as? [Any] {
                    report += "JSON root: array\nItem count: \(array.count)\n"
                }
                var sampleObject: Any = object
                if provider == "shabakaty",
                   let term = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "videoTitle" })?.value,
                   !term.isEmpty, let shows = try? Catalog.decodeShabakaty(bytes), let rows = object as? [[String: Any]] {
                    let scores = Dictionary(uniqueKeysWithValues: shows.map { ($0.sourceID ?? $0.id, TitleSearch.score($0, query: term)) })
                    func rank(_ row: [String: Any]) -> Int {
                        let id = (row["nb"] as? String) ?? (row["nb"] as? NSNumber)?.stringValue ?? ""
                        return scores[id] ?? 0
                    }
                    report += "Matching title count: \(shows.filter { TitleSearch.score($0, query: term) > 0 }.count)\nExact title count: \(shows.filter { TitleSearch.score($0, query: term) == 4 }.count)\n"
                    sampleObject = rows.sorted { rank($0) > rank($1) }
                }
                let sample = sanitizedSample(sampleObject, depth: 0)
                if JSONSerialization.isValidJSONObject(sample),
                   let data = try? JSONSerialization.data(withJSONObject: sample, options: [.prettyPrinted, .sortedKeys]),
                   let text = String(data: data, encoding: .utf8) {
                    report += "Redacted schema sample (limited):\n\(text)\n"
                }
                report += "Result: JSON received; playback access not tested\n"
            } catch {
                // Only an error code is exported; URLs, cookies, and auth values are excluded.
                let errorCode = (error as NSError).code
                report += "Result: connection error (\(errorCode))\n"
            }
        }
    }

    private func sanitizedSample(_ value: Any, depth: Int) -> Any {
        guard depth < 5 else { return "[nested value omitted]" }
        if let dictionary = value as? [String: Any] {
            var sample: [String: Any] = [:]
            for key in dictionary.keys.sorted().prefix(30) {
                let lower = key.lowercased()
                let sensitive = ["token", "password", "secret", "authorization", "cookie", "email", "phone", "username", "session", "credential", "key", "url", "link", "file"].contains { lower.contains($0) }
                if sensitive { sample[key] = "[redacted]" }
                else if let child = dictionary[key] { sample[key] = sanitizedSample(child, depth: depth + 1) }
            }
            return sample
        }
        if let array = value as? [Any] { return array.prefix(2).map { sanitizedSample($0, depth: depth + 1) } }
        if let string = value as? String {
            if string.contains("://") || string.count > 160 { return "[string omitted]" }
            return string
        }
        if value is NSNumber || value is NSNull { return value }
        return "[value omitted]"
    }
}
