#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
  echo "This build requires macOS and Xcode."
  exit 1
fi
build_dir="$project_root/build"
xcodebuild -project "$project_root/Shashatna.xcodeproj" \
  -scheme Shashatna -configuration Release -sdk iphoneos \
  -destination 'generic/platform=iOS' -derivedDataPath "$build_dir/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
app_path="$build_dir/DerivedData/Build/Products/Release-iphoneos/Shashatna.app"
[[ -d "$app_path" ]] || { echo "Built app not found"; exit 1; }
package_dir="$(mktemp -d "$build_dir/package.XXXXXX")"
trap 'rm -rf "$package_dir"' EXIT
mkdir -p "$package_dir/Payload"
cp -R "$app_path" "$package_dir/Payload/"
output_path="$build_dir/Shashatna-unsigned.ipa"
rm -f "$output_path"
(cd "$package_dir" && /usr/bin/zip -q -r -y "$output_path" Payload)
echo "Created unsigned IPA: $output_path"
echo "It must be signed with a valid certificate and matching provisioning profile before installation."
