#!/usr/bin/env python3
"""Compile production connection routing and execute offline fixtures on macOS."""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parents[1]
s=(root/'Shashatna/LibraryExplorer.swift').read_text()
production=s[s.index('enum LibraryAPI {'):s.index('@MainActor final class LibraryBrowseModel')]
tests=r'''
actor ConnectionFixture {
    var calls:[String]=[]
    var behavior="html"
    func reset(_ value:String){calls=[];behavior=value}
    func hosts()->[String]{calls}
    func read(_ url:URL)throws->Data {
        calls.append(url.host!)
        if behavior=="cancel" {throw CancellationError()}
        if behavior=="empty" {return Data("[]".utf8)}
        if url.host=="cee.buzz" {return Data("<html>unavailable</html>".utf8)}
        return Data("[{\"nb\":\"84\",\"ar_title\":\"اكشن\"}]".utf8)
    }
}
@main struct ConnectionRegression {
    static func expect(_ condition:Bool,_ name:String){if !condition {fatalError("Connection regression: "+name)}}
    static func main() async throws {
        let api=URL(string:"https://cinemana.shabakaty.com/api/android/AdvancedSearch?videoTitle=%D8%AD%D8%A8%20%26%20Love&level=0&page=0&type=series")!
        let routed=LibraryAPI.candidates(api,mode:"hub")
        expect(routed.map { $0.host! } == ["cee.buzz","cinemana.shabakaty.com"],"HUB-first and original fallback")
        expect(routed[0].path==api.path && routed[0].query==api.query,"preserve path and encoded search query")
        expect(LibraryAPI.candidates(api,mode:"shabakaty")[0].host=="cinemana.shabakaty.com","original-first option")
        expect(routed.allSatisfy { $0.scheme=="https" },"HTTPS only")
        for raw in ["https://cdn.cee.buzz/video.mp4?signature=original", "https://api.tvmaze.com/search/shows?q=test", "https://cinemana.shabakaty.com/api/android/userSettings", "https://cinemana.shabakaty.com/api/android/categories?token=secret"] {
            let url=URL(string:raw)!;expect(LibraryAPI.candidates(url,mode:"hub")==[url],"do not rewrite streams, external services, account paths or credentialed query")
        }
        let fixture=ConnectionFixture()
        let bytes=try await LibraryAPI.read(api,mode:"hub",loader:{try await fixture.read($0)})
        expect((try JSONSerialization.jsonObject(with:bytes) as? [[String:String]])?.first?["nb"]=="84","HTML rejection then valid JSON fallback")
        let firstCalls=await fixture.hosts();expect(firstCalls==["cee.buzz","cinemana.shabakaty.com"],"both endpoints tried on invalid response")
        await fixture.reset("empty")
        _=try await LibraryAPI.read(api,mode:"hub",loader:{try await fixture.read($0)})
        let emptyCalls=await fixture.hosts();expect(emptyCalls==["cee.buzz"],"valid empty JSON is not a network failure")
        await fixture.reset("cancel")
        do {_=try await LibraryAPI.read(api,mode:"hub",loader:{try await fixture.read($0)});fatalError("Cancellation was swallowed")}
        catch is CancellationError {}
        let cancelledCalls=await fixture.hosts();expect(cancelledCalls==["cee.buzz"],"cancellation must not trigger a fallback")
        print("Connection regression checks passed")
    }
}
'''
with tempfile.TemporaryDirectory(prefix='shashatna-connection-') as tmp:
    path=Path(tmp)/'ConnectionRegression.swift';binary=Path(tmp)/'connection-regression'
    path.write_text('import Foundation\n'+production+'\n'+tests)
    subprocess.run(['swiftc','-parse-as-library',str(path),'-o',str(binary)],check=True)
    subprocess.run([str(binary)],check=True)
print('Connection regression verified')
