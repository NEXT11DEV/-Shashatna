#!/usr/bin/env python3
"""Exercise the production homepage model with deterministic source responses on macOS."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root / 'Shashatna/ShashatnaApp.swift').read_text()
models = source[source.index('struct Episode:'):source.index('enum Theme {')]
catalog = source[source.index('@MainActor final class Catalog:'):source.index('@main struct ShashatnaApp:')]
fixtures = r'''
import Foundation
import Combine

enum LibraryAPI {
    enum Failure: Error { case unavailable }
    static func read(_ url: URL) async throws -> Data { try await HomeFixture.shared.read(url) }
}
actor HomeFixture {
    static let shared = HomeFixture()
    var responses: [String: Data] = [:]
    var calls: [String] = []
    var failed = Set<String>()
    func configure(failed: Set<String> = []) throws {
        self.failed = failed; calls = []; responses = [:]
        for (index, feed) in HomeFeed.allCases.enumerated() {
            let kind = feed == .popularMovies || feed == .latestMovies ? "1" : "2"
            let row: [String: Any] = ["nb": String(101 + index), "ar_title": "Fixture \(index)", "kind": kind]
            let wrongKind: [String: Any] = ["nb": "999", "ar_title": "Wrong media type", "kind": kind == "1" ? "2" : "1"]
            responses[feed.url.path] = try JSONSerialization.data(withJSONObject: [row, wrongKind])
        }
    }
    func read(_ url: URL) throws -> Data {
        calls.append(url.path)
        guard !failed.contains(url.path), let data = responses[url.path] else { throw LibraryAPI.Failure.unavailable }
        return data
    }
    func paths() -> [String] { calls }
}
'''
tests = r'''
@main struct HomeRegression {
    @MainActor static func main() async throws {
        func expect(_ condition: Bool, _ label: String) {
            if !condition {
                FileHandle.standardError.write(Data(("FAILED: " + label + "\n").utf8))
                exit(1)
            }
        }
        let fixture = HomeFixture.shared
        try await fixture.configure()
        let catalog = Catalog()
        await catalog.load(source: "shabakaty")
        expect(catalog.homeShelves.map(\.feed) == HomeFeed.allCases, "home keeps the four editorial source sections in order")
        expect(catalog.homeShelves.allSatisfy { $0.shows.count == 1 }, "movies and series remain in their own sections")
        let calls = await fixture.paths()
        expect(calls.count == 4 && !calls.contains { $0.contains("AdvancedSearch") }, "homepage must not use empty search results")
        expect(!catalog.loading && catalog.message == nil, "successful homepage load completes")
        let ranked = catalog.homeShelves.first!.shows.map(\.id)
        catalog.shows.reverse()
        expect(catalog.homeShelves.first!.shows.map(\.id) == ranked, "search cache order cannot change featured or ranked works")
        try await fixture.configure(failed: [HomeFeed.popularMovies.url.path])
        await catalog.load(source: "shabakaty")
        expect(catalog.homeShelves.count == 4 && catalog.homeShelves.first!.shows.map(\.id) == ranked, "a failed refresh preserves the previous section")
        expect(catalog.message != nil && !catalog.loading, "partial refresh exposes retry status")
        try await fixture.configure(failed: Set(HomeFeed.allCases.map { $0.url.path }))
        let offline = Catalog()
        await offline.load(source: "shabakaty")
        expect(offline.homeShelves.isEmpty && offline.message != nil, "failed first load must not disguise demo or search rows as popular")
        print("Homepage regressions passed against production catalog code")
    }
}
'''
with tempfile.TemporaryDirectory(prefix='shashatna-home-') as temporary:
    test = Path(temporary) / 'HomeRegression.swift'
    binary = Path(temporary) / 'home-regression'
    test.write_text(fixtures + models + catalog + tests)
    subprocess.run(['swiftc', '-swift-version', '5', '-parse-as-library', str(test), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
