#!/usr/bin/env python3
"""Compile production URLSession media resolver and run offline responses on macOS."""
from pathlib import Path
import tempfile, subprocess
r = Path(__file__).resolve().parents[1]
s = (r / 'Shashatna/PlaybackOptions.swift').read_text()
profile = s[s.index('enum CinemanaPlaybackProfile {'):s.index('// Wall-clock budget:')]
production = profile + s[s.index('enum MediaProbeSummary {'):s.index('struct PlaybackDiagnosticsView:')]
tests = r'''
final class MediaFixtureProtocol: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        guard request.value(forHTTPHeaderField: "Range") == "bytes=0-1023" else {
            client?.urlProtocol(self, didFailWithError: NSError(domain: "FixtureMissingRange", code: 1)); return
        }
        guard request.value(forHTTPHeaderField: "User-Agent") == CinemanaPlaybackProfile.userAgent,
              request.value(forHTTPHeaderField: "Accept") == "*/*" else {
            client?.urlProtocol(self, didFailWithError: NSError(domain: "FixtureMissingProfile", code: 2)); return
        }
        let path = request.url!.path
        if path == "/timeout" {
            client?.urlProtocol(self, didFailWithError: NSError(domain: NSURLErrorDomain, code: NSURLErrorTimedOut)); return
        }
        let final = URL(string: "https://cndw6.cee.buzz/video/a%2Fb.mp4?signature=a%2Bb%2F%3D&x=1&x=2")!
        let mime = path == "/html" ? "text/html" : "video/mp4"
        let status = path == "/forbidden" ? 403 : 206
        let response = HTTPURLResponse(url: final, statusCode: status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": mime, "Content-Range": "bytes 0-1023/9000"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        if path != "/empty" {
            let data = path == "/html" ? Data("<!DOCTYPE html>unavailable".utf8) : Data([0,0,0,20]) + Data("ftyp".utf8) + Data(repeating: 0, count: 2040)
            client?.urlProtocol(self, didLoad: data)
        }
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
@main struct ResolutionRegression {
    static func expect(_ value: Bool, _ name: String) { if !value { fatalError("Resolution regression: " + name) } }
    static func main() async {
        for path in ["ok", "html", "timeout", "empty", "forbidden"] {
            let url = URL(string: "https://cdn.cee.buzz/" + path)!
            let result = await MediaReachabilityProbe(url: url, protocolClasses: [MediaFixtureProtocol.self]).run()
            if path == "ok" {
                expect(result.verifiedURL?.host == "cndw6.cee.buzz", "use response's final host")
                expect(result.verifiedURL?.absoluteString == "https://cndw6.cee.buzz/video/a%2Fb.mp4?signature=a%2Bb%2F%3D&x=1&x=2", "final signed URL unchanged")
                expect(result.summary.contains("Sample bytes: 512"), "retained sample capped even if Range ignored")
            } else {
                expect(result.verifiedURL == nil, "do not select a failed or unverified response: " + path)
            }
            expect(!result.summary.contains("signature=") && !result.summary.contains("a%2Fb"), "report hides signed URL and path")
            if path == "timeout" { expect(result.summary.contains("-1001"), "timeout code retained") }
        }
        let final = URL(string: "https://cndw6.cee.buzz/a.mp4?token=x")!
        let bytes = Data([0,0,0,20]) + Data("ftyp".utf8)
        expect(MediaProbeSummary.acceptedURL(status: 206, mime: "video/mp4", prefix: bytes, url: final, redirectBlocked: true) == nil, "blocked redirect rejected")
        expect(MediaProbeSummary.acceptedURL(status: 206, mime: "video/mp4", prefix: bytes, url: URL(string: "http://cndw6.cee.buzz/a.mp4"), redirectBlocked: false) == nil, "HTTP not promoted")
        print("Media resolution fixtures passed")
    }
}
'''
with tempfile.TemporaryDirectory(prefix='shashatna-resolution-') as tmp:
    source = Path(tmp) / 'ResolutionRegression.swift'; binary = Path(tmp) / 'resolution-regression'
    source.write_text('import Foundation\n' + production + '\n' + tests)
    subprocess.run(['swiftc', '-parse-as-library', str(source), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True, timeout=45)
