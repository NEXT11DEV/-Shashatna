#!/usr/bin/env python3
"""Compile scoped production compatibility headers and signed URL fixtures on macOS."""
from pathlib import Path
import tempfile, subprocess
r = Path(__file__).resolve().parents[1]
s = (r / 'Shashatna/PlaybackOptions.swift').read_text()
production = s[s.index('enum CinemanaPlaybackProfile {'):s.index('// Wall-clock budget:')]
tests = r'''
func expect(_ value: Bool, _ name: String) { if !value { fatalError("Profile regression: " + name) } }
for host in ["cdn.cee.buzz", "cdn.shabakaty.com", "cnth2.cee.buzz", "cndw8.cee.buzz", "cndw16.cee.buzz"] {
    let raw = "https://" + host + "/a%2Fb.mp4?signature=a%2Bb%2F%3D&x=1&x=2"
    let url = URL(string: raw)!
    var request = URLRequest(url: url)
    request.allowsCellularAccess = false
    CinemanaPlaybackProfile.apply(to: &request)
    expect(request.value(forHTTPHeaderField: "User-Agent") == "Cinemana/5.3.3 (Linux; Android 13; Pixel) AppleWebKit/537.36 okhttp/4.9.0", "observed compatibility user agent")
    expect(request.value(forHTTPHeaderField: "Accept") == "*/*", "observed Accept header")
    expect(request.url?.absoluteString == raw, "signed URL is never rebuilt by header profile")
    expect(!request.allowsCellularAccess, "Wi-Fi-only preference is preserved")
    expect(request.value(forHTTPHeaderField: "Authorization") == nil && request.value(forHTTPHeaderField: "Cookie") == nil, "no borrowed credentials")
}
for raw in ["https://example.com/a.mp4", "https://cdn.cee.buzz.evil.example/a.mp4", "https://cndw8.evil.cee.buzz/a.mp4", "https://cndw.cee.buzz/a.mp4", "http://cdn.cee.buzz/a.mp4", "file:///private/offline.mp4", "https://user:password@cdn.cee.buzz/a.mp4"] {
    let url = URL(string: raw)!
    var request = URLRequest(url: url)
    request.setValue("MyCustomClient", forHTTPHeaderField: "User-Agent")
    CinemanaPlaybackProfile.apply(to: &request)
    expect(request.value(forHTTPHeaderField: "User-Agent") == "MyCustomClient", "unrelated URLs retain caller headers")
    expect(request.value(forHTTPHeaderField: "Accept") == nil, "profile stays scoped")
}
expect(CinemanaPlaybackProfile.forwardBufferDuration == 2, "buffer value observed at HUB call site")
print("Playback compatibility profile fixtures passed")
'''
with tempfile.TemporaryDirectory(prefix='shashatna-profile-') as tmp:
    source = Path(tmp) / 'ProfileRegression.swift'; binary = Path(tmp) / 'profile-regression'
    source.write_text('import Foundation\n' + production + '\n' + tests)
    subprocess.run(['swiftc', str(source), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
