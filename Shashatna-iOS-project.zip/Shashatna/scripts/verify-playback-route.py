#!/usr/bin/env python3
"""Run production media host routing against signed-URL fixtures on macOS."""
from pathlib import Path
import subprocess, tempfile
root = Path(__file__).resolve().parents[1]
s = (root / 'Shashatna/PlaybackOptions.swift').read_text()
production = s[s.index('enum CinemanaMediaRoute {'):s.index('// Keep one AVPlayer')]
tests = r'''
func expect(_ condition: Bool, _ name: String) {
    if !condition { fatalError("Media route regression: " + name) }
}
for (old, new) in [("cdn.shabakaty.com", "cdn.cee.buzz"),
                   ("cnth2.shabakaty.com", "cnth2.cee.buzz"),
                   ("cnth.shabakaty.com", "cnth.cee.buzz")] {
    let raw = "https://" + old + "/video/a%2Fb.mp4?token=a%2Bb%2F%3D&expires=1790000000&x=1&x=2"
    let source = URL(string: raw)!
    let hub = CinemanaMediaRoute.candidates(source, mode: "auto")
    expect(hub.count == 2 && hub.map { $0.host! } == [new, old], "bounded alternate list")
    expect(hub[0].absoluteString == raw.replacingOccurrences(of: old, with: new), "signed path and query bytes preserved")
    expect(hub[1] == source, "original fallback preserved in auto")
    expect(CinemanaMediaRoute.candidates(source, mode: "hub") == [hub[0]], "explicit HUB mode must not fall back to Shabakaty")
    expect(CinemanaMediaRoute.candidates(hub[0], mode: "shabakaty").map { $0.host! } == [old, new], "reverse routing")
    expect(CinemanaMediaRoute.candidates(hub[0], mode: "auto") == hub, "idempotent routing")
}
for raw in ["file:///private/test.mp4", "https://example.com/a.m3u8?cdn.shabakaty.com",
            "http://cdn.shabakaty.com/a.mp4", "https://cdn.shabakaty.com.evil.example/a.mp4",
            "https://user:password@cdn.shabakaty.com/a.mp4",
            "https://cinemana.shabakaty.com/api/android/categories"] {
    let url = URL(string: raw)!
    expect(CinemanaMediaRoute.candidates(url, mode: "hub") == [url], "unrelated or credentialed URL unchanged")
}
print("Media routing fixtures passed")
'''
with tempfile.TemporaryDirectory(prefix='shashatna-media-') as tmp:
    path = Path(tmp) / 'MediaRegression.swift'
    binary = Path(tmp) / 'media-regression'
    path.write_text('import Foundation\n' + production + '\n' + tests)
    subprocess.run(['swiftc', str(path), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
