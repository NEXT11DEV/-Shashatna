#!/usr/bin/env python3
"""Compile actual timeout/redaction helpers and run deterministic fixtures on macOS."""
from pathlib import Path
import tempfile, subprocess
root = Path(__file__).resolve().parents[1]
s = (root / 'Shashatna/PlaybackOptions.swift').read_text()
budget = s[s.index('struct PlaybackWaitBudget {'):s.index('// Keep one AVPlayer')]
summary = s[s.index('enum MediaProbeSummary {'):s.index('// Delegate state is confined')]
tests = r'''
func expect(_ condition: Bool, _ name: String) { if !condition { fatalError(name) } }
var wait = PlaybackWaitBudget()
expect(!wait.expired(now: 500, waiting: false), "Pre-created view does not start watchdog")
expect(!wait.expired(now: 1000, waiting: true), "Waiting starts deadline")
expect(!wait.expired(now: 1029, waiting: true), "No premature timeout")
expect(wait.expired(now: 1030, waiting: true), "Stalled startup is bounded")
expect(wait.elapsed(now: 1031) == 31, "Elapsed monotonic time")
wait.reset()
expect(wait.elapsed(now: 3000) == 0, "Pause/reset clears budget")
expect(!wait.expired(now: 4000, waiting: true), "Later playback receives a fresh budget")
expect(PlaybackFailurePolicy.waitLimit() == 30, "Diagnostic deadline is not a scheduled playback delay")
expect(!PlaybackFailurePolicy.shouldTryNext(timedOut: true), "Do not mask a local deadline with a dead-host error")
expect(PlaybackFailurePolicy.shouldTryNext(timedOut: false), "Actual failure may try configured alternate")
let mp4 = Data([0,0,0,20]) + Data("ftypisom".utf8)
expect(MediaProbeSummary.bodyKind(mp4, mime: "application/octet-stream").contains("MP4"), "MP4 header")
expect(MediaProbeSummary.bodyKind(Data("#EXTM3U\n".utf8), mime: "application/vnd.apple.mpegurl").contains("HLS"), "Playlist header")
expect(MediaProbeSummary.bodyKind(Data("  <!DOCTYPE html>".utf8), mime: "text/plain").contains("HTML"), "HTML masquerading as text")
expect(MediaProbeSummary.bodyKind(Data("{}".utf8), mime: "application/json").contains("not video"), "JSON is not playback")
expect(MediaProbeSummary.bodyKind(Data(), mime: "video/mp4").contains("No body"), "Headers alone do not prove bytes arrived")
let secret = "https://cdn.cee.buzz/private.mp4?token=DO_NOT_EXPORT"
let inner = NSError(domain: NSURLErrorDomain, code: -1004, userInfo: [NSLocalizedDescriptionKey: secret])
let outer = NSError(domain: "AVFoundationErrorDomain", code: -11800, userInfo: [NSUnderlyingErrorKey: inner, NSURLErrorFailingURLErrorKey: secret])
let report = MediaProbeSummary.errorCodes(outer)
expect(report.contains("-11800") && report.contains("-1004"), "Underlying network code retained")
expect(!report.contains("https") && !report.contains("DO_NOT_EXPORT"), "No signed URL or error-description leakage")
print("Playback wall-clock and redaction fixtures passed")
'''
with tempfile.TemporaryDirectory(prefix='shashatna-wait-') as tmp:
    source = Path(tmp) / 'WaitRegression.swift'; binary = Path(tmp) / 'wait-regression'
    source.write_text('import Foundation\n' + budget + '\n' + summary + '\n' + tests)
    subprocess.run(['swiftc', str(source), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
