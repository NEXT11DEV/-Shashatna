#!/usr/bin/env python3
"""Compile and exercise the actual search/pagination source on the macOS builder."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root / 'Shashatna/LibraryExplorer.swift').read_text()
production = source[source.index('@MainActor final class LibraryBrowseModel'):source.index('struct LibraryExplorerView')]
fixtures = r'''
import Foundation
import Combine

struct Show {
    var id: String = ""
    var title: String = ""
    var category: String = ""
    var sourceGenres: [String]? = nil
    var alternateTitles: [String]? = nil
}
enum LibraryAPI {
    enum APIError: Error { case response }
    static func read(_ url: URL) async throws -> Data { try await SearchFixture.shared.read(url) }
}
actor SearchFixture {
    static let shared = SearchFixture()
    var rows: [String: [String]] = [:]
    var failOnce = Set<String>()
    var calls: [String: Int] = [:]
    func configure(_ rows: [String: [String]], failOnce: Set<String> = []) {
        self.rows = rows; self.failOnce = failOnce; calls = [:]
    }
    func read(_ url: URL) throws -> Data {
        let parts = URLComponents(url: url, resolvingAgainstBaseURL: false)!.queryItems!
        let type = parts.first { $0.name == "type" }?.value ?? ""
        let page = parts.first { $0.name == "page" }!.value!
        let key = type + ":" + page
        calls[key, default: 0] += 1
        if failOnce.remove(key) != nil { throw LibraryAPI.APIError.response }
        return try JSONSerialization.data(withJSONObject: (rows[key] ?? []).map { ["id": $0] })
    }
    func count(_ key: String) -> Int { calls[key, default: 0] }
}
@MainActor enum Catalog {
    static func decodeShabakaty(_ data: Data) throws -> [Show] {
        let rows = try JSONSerialization.jsonObject(with: data) as! [[String: String]]
        return rows.map { Show(id: $0["id"]!, title: $0["id"]!) }
    }
}
'''
tests = r'''
@main struct SearchRegression {
    @MainActor static func main() async {
        var failures: [String] = []
        func expect(_ condition: Bool, _ label: String) {
            if !condition { failures.append(label) }
        }
        func expectNormalized(_ input: String, _ expected: String, _ label: String) {
            let actual = TitleSearch.normalized(input)
            expect(actual == expected, label + ": expected " + String(reflecting: expected) + ", got " + String(reflecting: actual))
        }
        expect(TitleSearch.variants("Cukur").contains("Çukur"), "preserve Turkish diacritics in requests")
        expect(TitleSearch.variants("الحفرة").contains("The Pit"), "do not truncate the fourth title alias")
        expect(TitleSearch.variants("حب بلا حدود").contains("Hudutsuz Sevda"), "cross-language alias")
        expect(TitleSearch.variants("Stranger Things").contains("Stranger"), "generic fallback for unfamiliar titles")
        expectNormalized("  \u{200f}الـحُفْرة  ", "الحفره", "Arabic diacritics, tatweel and invisible marks")
        expectNormalized("حُبّ بِلَا حُدُود", "حب بلا حدود", "Arabic vowels must not split words")
        expectNormalized("أَرْض إِبْرَاهِيم", "ارض ابراهيم", "decomposed Arabic hamza and vowel marks")
        expectNormalized("Çukur", "cukur", "Latin combining marks")
        expectNormalized("C\u{0327}ukur", "cukur", "precomposed and decomposed Latin forms agree")
        expectNormalized("\u{064E}\u{0651}", "", "marks-only query")
        expectNormalized("One—Crazy / Summer", "one crazy summer", "punctuation still separates words")
        expect(TitleSearch.normalized("Yeraltı") == TitleSearch.normalized("Yeralti"), "Turkish dotless i ranking")
        expect(TitleSearch.score(Show(title: "Summer Wars"), query: "One Crazy Summer") == 0, "token retrieval must not count as a title match")
        expect(TitleSearch.score(Show(title: "One Crazy Summer"), query: "One Crazy Summer") == 4, "exact match")
        expect(TitleSearch.score(Show(title: "Çukur", alternateTitles: ["الحفرة"]), query: "الحفرة") == 4, "alternate-title match")
        expect(TitleSearch.isAnimation(Show(category: "رسوم متحركة")), "animation fallback category")

        let request = LibraryBrowseModel.searchURL(query: "حُبّ بلا حدود & Love", mediaType: "movie", page: 0)
        let params = URLComponents(url: request, resolvingAgainstBaseURL: false)!.queryItems!
        expect(params.first { $0.name == "page" }?.value == "0", "search must include the first zero-based page")
        expect(params.first { $0.name == "type" }?.value == "movies", "API film type is plural movies")
        expect(params.first { $0.name == "level" }?.value == "0", "source search level")
        expect(params.first { $0.name == "videoTitle" }?.value == "حُبّ بلا حدود & Love", "encode the full query as one parameter")
        let untyped = LibraryBrowseModel.searchURL(query: "test", mediaType: "", page: 0)
        expect(!URLComponents(url: untyped, resolvingAgainstBaseURL: false)!.queryItems!.contains { $0.name == "type" }, "untyped fallback omits type")

        let fixture = SearchFixture.shared
        await fixture.configure(["series:0": ["Hudutsuz Sevda"]])
        let firstPageModel = LibraryBrowseModel()
        await firstPageModel.reset(query: "Hudutsuz Sevda", mediaType: "series")
        expect(firstPageModel.items.contains { $0.id == "Hudutsuz Sevda" }, "a title present only on page zero must be found")

        await fixture.configure(["movies:0": ["A"], "series:0": ["B"], "movies:1": ["B"], "series:1": ["A"], "movies:2": ["C"]])
        let model = LibraryBrowseModel()
        await model.reset(query: "", mediaType: "all")
        await model.more()
        expect(!model.ended && model.page == 2, "overlap with other branches must not stop pagination")
        await model.more()
        expect(model.items.contains { $0.id == "C" }, "later-page title remains discoverable")
        await model.more()
        expect(model.ended, "empty branches terminate pagination")

        await fixture.configure(["movies:0": ["A"], "series:0": ["B"], "movies:1": ["C"]], failOnce: ["series:0"])
        await model.reset(query: "", mediaType: "all")
        expect(model.message != nil && model.page == 0, "partial failure retains the page for retry")
        await model.more()
        let movieCalls = await fixture.count("movies:0")
        expect(movieCalls == 1, "retry must not refetch or finish a successful branch")
        expect(model.message == nil && Set(model.items.map(\.id)) == ["A", "B"], "retry merges the missing branch")
        await model.more()
        expect(model.items.contains { $0.id == "C" }, "successful branch remains live after retry")
        if !failures.isEmpty {
            let message = failures.map { "FAILED: " + $0 }.joined(separator: "\n") + "\n"
            FileHandle.standardError.write(Data(message.utf8))
            exit(1)
        }
        print("Search regressions passed against production search code")
    }
}
'''
with tempfile.TemporaryDirectory(prefix='shashatna-search-') as temporary:
    test = Path(temporary) / 'SearchRegression.swift'
    binary = Path(temporary) / 'search-regression'
    test.write_text(fixtures + production + tests)
    subprocess.run(['swiftc', '-swift-version', '5', '-parse-as-library', str(test), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
