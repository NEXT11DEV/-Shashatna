#!/usr/bin/env python3
"""Compile and exercise the actual search/pagination source on the macOS builder."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root / 'Shashatna/LibraryExplorer.swift').read_text()
production = source[source.index('@MainActor final class LibraryBrowseModel'):source.index('struct LibraryExplorerView')]
fixtures = r'''
import Foundation
import Combine

struct Show {
    var id: String = ""
    var title: String = ""
    var category: String = ""
    var sourceGenres: [String]? = nil
    var alternateTitles: [String]? = nil
}
enum LibraryAPI {
    enum APIError: Error { case response }
    static func read(_ url: URL) async throws -> Data { try await SearchFixture.shared.read(url) }
}
actor SearchFixture {
    static let shared = SearchFixture()
    var rows: [String: [String]] = [:]
    var failOnce = Set<String>()
    var calls: [String: Int] = [:]
    func configure(_ rows: [String: [String]], failOnce: Set<String> = []) {
        self.rows = rows; self.failOnce = failOnce; calls = [:]
    }
    func read(_ url: URL) throws -> Data {
        let parts = URLComponents(url: url, resolvingAgainstBaseURL: false)!.queryItems!
        let type = parts.first { $0.name == "type" }?.value ?? ""
        let page = parts.first { $0.name == "page" }!.value!
        let key = type + ":" + page
        calls[key, default: 0] += 1
        if failOnce.remove(key) != nil { throw LibraryAPI.APIError.response }
        return try JSONSerialization.data(withJSONObject: (rows[key] ?? []).map { ["id": $0] })
    }
    func count(_ key: String) -> Int { calls[key, default: 0] }
}
@MainActor enum Catalog {
    static func decodeShabakaty(_ data: Data) throws -> [Show] {
        let rows = try JSONSerialization.jsonObject(with: data) as! [[String: String]]
        return rows.map { Show(id: $0["id"]!, title: $0["id"]!) }
    }
}
'''
tests = r'''
@main struct SearchRegression {
    @MainActor static func main() async {
        func expect(_ condition: Bool, _ label: String) {
            guard condition else { fatalError("Search regression: " + label) }
        }
        expect(TitleSearch.variants("Cukur").contains("Çukur"), "preserve Turkish diacritics in requests")
        expect(TitleSearch.variants("الحفرة").contains("The Pit"), "do not truncate the fourth title alias")
        expect(TitleSearch.variants("حب بلا حدود").contains("Hudutsuz Sevda"), "cross-language alias")
        expect(TitleSearch.variants("Stranger Things").contains("Stranger"), "generic fallback for unfamiliar titles")
        expect(TitleSearch.normalized("  \u{200f}الـحُفْرة  ") == "الحفره", "Arabic diacritics, tatweel and invisible marks")
        expect(TitleSearch.normalized("Yeraltı") == TitleSearch.normalized("Yeralti"), "Turkish dotless i ranking")
        expect(TitleSearch.score(Show(title: "Summer Wars"), query: "One Crazy Summer") == 0, "token retrieval must not count as a title match")
        expect(TitleSearch.score(Show(title: "One Crazy Summer"), query: "One Crazy Summer") == 4, "exact match")
        expect(TitleSearch.score(Show(title: "Çukur", alternateTitles: ["الحفرة"]), query: "الحفرة") == 4, "alternate-title match")
        expect(TitleSearch.isAnimation(Show(category: "رسوم متحركة")), "animation fallback category")

        let fixture = SearchFixture.shared
        await fixture.configure(["movie:1": ["A"], "series:1": ["B"], "movie:2": ["B"], "series:2": ["A"], "movie:3": ["C"]])
        let model = LibraryBrowseModel()
        await model.reset(query: "", mediaType: "all")
        await model.more()
        expect(!model.ended && model.page == 3, "overlap with other branches must not stop pagination")
        await model.more()
        expect(model.items.contains { $0.id == "C" }, "later-page title remains discoverable")
        await model.more()
        expect(model.ended, "empty branches terminate pagination")

        await fixture.configure(["movie:1": ["A"], "series:1": ["B"], "movie:2": ["C"]], failOnce: ["series:1"])
        await model.reset(query: "", mediaType: "all")
        expect(model.message != nil && model.page == 1, "partial failure retains the page for retry")
        await model.more()
        let movieCalls = await fixture.count("movie:1")
        expect(movieCalls == 1, "retry must not refetch or finish a successful branch")
        expect(model.message == nil && Set(model.items.map(\.id)) == ["A", "B"], "retry merges the missing branch")
        await model.more()
        expect(model.items.contains { $0.id == "C" }, "successful branch remains live after retry")
        print("Search regressions passed against production search code")
    }
}
'''
with tempfile.TemporaryDirectory(prefix='shashatna-search-') as temporary:
    test = Path(temporary) / 'SearchRegression.swift'
    binary = Path(temporary) / 'search-regression'
    test.write_text(fixtures + production + tests)
    subprocess.run(['swiftc', '-swift-version', '5', '-parse-as-library', str(test), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
